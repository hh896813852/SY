var app = angular.module('app', [
            'ngSanitize',
            'ui.router',
            'AppService',
            'AppFactory',
            'AppProvider',
            'ngSideView',
            'pasvaz.bindonce'
  ]);

app.version = "1.1.0";
app.viewFloder = "/bundles/topxiamobilebundlev2/main/";

app.config(['$httpProvider', function($httpProvider) {

    $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
    // Override $http service's default transformRequest
    $httpProvider.defaults.transformRequest = [function(data) {

        /**
         * The workhorse; converts an object to x-www-form-urlencoded serialization.
         * @param {Object} obj
         * @return {String}
         */
        var param = function(obj) {
            var query = '';
            var name, value, fullSubName, subName, subValue, innerObj, i;
 
            for (name in obj) {
                value = obj[name];
 
                if (value instanceof Array) {
                    for (i = 0; i < value.length; ++i) {
                        subValue = value[i];
                        fullSubName = name + '[' + i + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if (value instanceof Object) {
                    for (subName in value) {
                        subValue = value[subName];
                        fullSubName = name + '[' + subName + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if (value !== undefined && value !== null) {
                    query += encodeURIComponent(name) + '='
                            + encodeURIComponent(value) + '&';
                }
            }
 
            return query.length ? query.substr(0, query.length - 1) : query;
        };
 
        return angular.isObject(data) && String(data) !== '[object File]'
                ? param(data)
                : data;
    }];
}]);

app.config([ 'appRouterProvider', '$urlRouterProvider', function(appRouterProvider, $urlRouterProvider)
{
  $urlRouterProvider.when("/", "/index").
  otherwise('/index');

  appRouterProvider.init();
}]);

app.run(["applicationProvider", "$rootScope", '$timeout', 'platformUtil',
  function(applicationProvider, $rootScope, $timeout, platformUtil) {

  $rootScope.platform = platformUtil;
  $rootScope.showLoad = function(template) {
    if ($rootScope.loadPop) {
      $rootScope.loadPop.loading("hide");
    }
    $rootScope.loadPop = $.loading({
        content: template ? template : "加载中...",
    });

    $timeout(function(){
        if ($rootScope.loadPop) {
          $rootScope.loadPop.loading("hide");
        }
    },15000);
  };

  $rootScope.toast = function(template) {
    var el = $.tips({
        content: template,
        stayTime: 2000,
        type: "info"
    });

    $timeout(function(){
        el.loading("hide");
    },2000);
  };

  $rootScope.hideLoad = function() {
    if (! $rootScope.loadPop) {
      return;
    }
    $rootScope.loadPop.loading("hide");
    $rootScope.loadPop = null;
  };

  app.host = getOriginHost();
  app.rootPath = window.location.origin + window.location.pathname;
  $rootScope.stateParams = {};

  applicationProvider.init(app.host);
  FastClick.attach(document.body);
}]);

function getOriginHost() {
  var location = window.location;
  var pathname = location.pathname;
  var index = pathname.indexOf("/mapi_v2");
  if (index != -1) {
    return location.origin + pathname.substring(0, index);
  }

  return location.origin;
};

angular.element(document).ready(function() {
    var platformUtil = angular.injector(["AppFactory", "ng"]).get("platformUtil");
    if (platformUtil.native) {
      if (platformUtil.android && window.cordova.isDeviceready()) {
        angular.bootstrap( document, ["app"] );
        return;
      }
      document.addEventListener("deviceready", function() {
          angular.bootstrap( document, ["app"] );
      });
      return;
    }
    
    angular.bootstrap( document, ["app"] );
});
;
var appFactory = angular.module('AppFactory', []);
appFactory.factory('AppUtil', ['$timeout', function($timeout) {
	var utils = {
		formatString : function(str) {
			var args = arguments, re = new RegExp("%([1-" + args.length + "])", "g");
			return String(str).replace(re, function($1, $2) {
				return args[$2];
			});
		},
		createArray : function(count) {
			var arr = [];
			for (var i = count- 1; i >= 0; i--) {
				arr.unshift(i);
			};

			return arr;
		},
		coverCategoty : function(categoryTree) {
			var categorys = [];
			for (var i = categoryTree.length - 1; i >= 0; i--) {
				categorys.unshift(categoryTree[i]);
			};
		},
		showPop : function(opts, callback) {
			var confirmPopup = $ionicPopup.confirm({
			     title: opts.title,
			     template: opts.template,
			     okText : opts.okText || "确定",
			     cancelText : opts.cancelText || "取消"
			});
			
			confirmPopup.then(function(res) {
				callback(res);
			});
		},
		createDialog : function(title, template, btns, modalInitFunc) {
			
			var dia=$.dialog({
			        title: title,
			        content: template,
			        button: btns || ["确认"]
			});

			dia.on("dialog:action",function(e){
			       modalInitFunc(e.index);
			       dia.dialog("hide");
			});
		},
		inArray : function(elem, arr, i) {
			    var len;
			    var deletedIds = [];
			    var indexOf = deletedIds.indexOf;
			    if ( arr ) {
			        if ( indexOf ) {
			            return indexOf.call( arr, elem, i );
			        }
			        len = arr.length;
			        i = i ? i < 0 ? Math.max( 0, len + i ) : i : 0;
			        for ( ; i < len; i++ ) {
			            if ( i in arr && arr[ i ] === elem ) {
			                return i;
			            }
			        }
			    }

			    return -1;
		}
	};
	
	return utils;
}]).
factory('ServcieUtil', function() {

	return {
		getService : function(name) {
			return angular.injector(["AppService", "ng"]).get(name);
		}
	}
}).
factory('ClassRoomUtil', function() {
	var getService = function() {
		return {
			"homeworkReview" : {
				title : "24小时作业批改",
				class : "homeworkReview",
				name : "练"
			},
			"testpaperReview" : {
				title : "24小时阅卷点评",
				class : "testpaperReview",
				name : "试"
			},
			"teacherAnswer" : {
				title : "提问必答",
				class : "teacherAnswer",
				name : "问"
			},
			"liveAnswer" : {
				title : "一对一在线答疑",
				class : "liveAnswer",
				name : "疑"
			},
			"event" : {
				title : "班级活动",
				class : "event",
				name : "动"
			},
			"workAdvise" : {
				title : "就业指导",
				class : "workAdvise",
				name : "业"
			},
		};
	};

	var filter = function(classRoom) {
		var classRoomService = classRoom.service;
		var service = getService();
		if (!classRoomService || classRoomService == "null") {
			classRoom.service = service;
			return classRoom;
		}
		for (var j = 0; j < classRoomService.length; j++) {
			service[classRoomService[j]].class = "active";
		};
		classRoom.service = service;

		return classRoom;
	};

	var cover = function(classRoom) {
		var classRoomService = classRoom.service;
		var service = getService();
		if (!classRoomService || classRoomService == "null") {
			classRoom.service = [];
			return classRoom;
		}
		for (var i = 0; i < classRoomService.length; i++) {
			classRoomService[i] = service[classRoomService[i]];
		};

		return classRoom;
	};

	return {
		filterClassRoom : function(classRoom) {
			return cover(classRoom);
		},
		filterClassRooms : function(classRooms) {
				for (var i = 0; i < classRooms.length; i++) {
					var classRoomService = classRooms[i].service;
					classRooms[i] = cover(classRooms[i]);
				};

				return classRooms;
			}
	}
}).
factory('VipUtil', function() {

	var payByYear = {
		title : "按年购买",
		type : 20,
		name : "year"
	};

	var payByMonth  ={
		title : "按月购买",
		type : 30,
		name : "month"
	};

	return {
		getPayType : function() {
			return {
				byYead : 20,
				byMonth : 30
			}
		},
		getPayMode : function(buyType) {
			
			if (buyType == 10) {
				return [payByYear, payByMonth];
			} else if (buyType == 20) {
				return [payByYear];
			} else {
				return [payByMonth];
			}
		}
	}
}).
factory('broadCast', ['$rootScope', function($rootScope) {
	angular.broadQueue = [];
	var broadCastService = {
		bind : function(event, callback){
			angular.broadQueue[event] = callback;
		},
		send : function(event, msg){
			callback = angular.broadQueue[event];
			//delete angular.broadQueue[event];
			callback(event, msg);
		}
	};
	return broadCastService;
}]).
factory('CourseUtil', ['$rootScope', 'CourseService', 'ClassRoomService' ,function(
	$rootScope, CourseService, ClassRoomService) {
	
	return {
		getFavoriteListTypes : function() {
			return {
				'course' : {
					url : "Course/getFavoriteNormalCourse",
					data : undefined,
					start : 0,
					canLoad : true
				},
				'live' : {
					url : "Course/getFavoriteLiveCourse",
					data : undefined,
					start : 0,
					canLoad : true
				}
			}
		},

		getCourseListTypes  : function() {
			return [
		  		{
		  			name : "课程",
		  			type : "normal"
		  		},
		  		{
		  			name : "直播",
		  			type : "live"
		  		}
		  	]
		},

		getCourseListSorts : function() {
			return [
		  		{
		  			name : "最新",
		  			type : "-createdTime"
		  		},
		  		{
		  			name : "最热",
		  			type : "-studentNum"
		  		},
		  		{
		  			name : "推荐",
		  			type : "recommendedSeq"
		  		}
		  	]
		},

		getClassRoomListSorts : function() {
			return [
		  		{
		  			name : "最新",
		  			type : "createdTime"
		  		},
		  		{
		  			name : "推荐",
		  			type : "recommendedSeq"
		  		}
		  	]
		}
	};
}]).
factory('platformUtil', function() {
	var browser = {
	    v: (function(){
	        var u = navigator.userAgent, p = navigator.platform;
	        return {
	            trident: u.indexOf('Trident') > -1, //IE内核
	            presto: u.indexOf('Presto') > -1, //opera内核
	            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
	            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
	            mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
	            ios: !!u.match(/i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
	            android: u.indexOf('Android') > -1, //android终端
	            iPhone: u.indexOf('iPhone') > -1 , //是否为iPhone或者QQHD浏览器
	            iPad: u.indexOf('iPad') > -1, //是否iPad
	            weixin: u.indexOf('MicroMessenger') > -1, //是否微信
	            webApp: u.indexOf('Safari') == -1, //是否web应用程序，没有头部与底部
	            UCB: u.match(/UCBrowser/i) == "UCBrowser",
	            QQB: u.match(/MQQBrowser/i) == "MQQBrowser",
	            win: p.indexOf('Win') > -1,//判断是否是WIN操作系统
	            mac: p.indexOf('Mac') > -1,//判断是否是Mac操作系统
	            native: u.indexOf('kuozhi') > -1, //是否native应用程序，没有头部与底部
	        };
	    })()
	};
	
	return browser.v;
}).
factory('cordovaUtil', ['$rootScope', 'sideDelegate', 'localStore', 'platformUtil', 
	function($rootScope, sideDelegate, localStore, platformUtil){
	var cordovaUtil =  {
		learnCourseLesson : function(courseId, lessonId) {
			alert("请在客户端学习非图文课时");
		},
		share : function(url, title, about, pic) {
			alert("请在客户端分享");
		},
		openDrawer : function(state) {
			sideDelegate.toggleMenu();
		},
		openWebView : function(url) {
			window.location.href = url;
		},
		pay : function(title, url) {
			alert("请在客户端内支付!");
		},
		getUserToken : function($q) {
			var deferred = $q.defer();
			deferred.resolve({
				user : angular.fromJson(localStore.get("user")),
				token : localStore.get("token")
			});

			return deferred.promise;
		},
		clearUserToken : function() {
			localStore.remove("user");
			localStore.remove("token");
		},
		saveUserToken : function(user, token) {
			localStore.save("user", angular.toJson(user));
			localStore.save("token", token);
		},
		showDownLesson : function(courseId) {
			alert("请在客户端下载课时");
		},
		showCourseSetting : function (courseId) {
			alert("请在客户端下进入课程详情");
		},
		closeWebView : function() {
			window.history.back();
		},
		backWebView : function() {
			window.history.back();
		},
		openPlatformLogin : function(type) {
			alert("请在客户端内登录!");
		},
		showInput : function(title, content, type, successCallback) {
			alert("该功能仅支持客户端!");
		},
		startAppView : function(name, data) {
			alert("该功能仅支持客户端!");
		},
		updateUser : function(user) {
		},
		uploadImage : function($q, url, headers, params, acceptType) {
			var deferred = $q.defer();
			deferred.resolve(null);
			return deferred.promise;
		},
		redirect : function(body) {
			alert("请在app内转发分享");
		},
		getThirdConfig : function($q) {
			var deferred = $q.defer();
			deferred.resolve([]);

			return deferred.promise;
		},
		sendNativeMessage : function(type, data) {
			if ("token_lose" == type) {
				$rootScope.user = null;
				$rootScope.token = null;
				localStore.remove("user");
				localStore.remove("token");
				alert("登录信息失效，请重新登录");
			}
		},
		getSupportLiveClients : function($q) {
			var deferred = $q.defer();
			deferred.resolve([]);
			return deferred.promise;
		},
		openNativeCourseDetailPage : function(courseId, type) {
		},
		openNativeClassroomDetailPage : function(classRoomId) {
		}
	};

	var publicCordovaUtil = {
		addEvent : function(name, callback) {
			if (window.jsBridgeAdapter) {
				window.jsBridgeAdapter.addEvent(name, callback);
			}
		}
	};

	var proxy = function() {
		var self = {};

		var isNative = platformUtil.native;
		for ( var func in cordovaUtil) {
			var nativeFunc = window.esNativeCore ? esNativeCore[func]: null;
			
			self[func] = isNative ? nativeFunc : cordovaUtil[func];
		}

		for ( var func in publicCordovaUtil) {
			self[func] = publicCordovaUtil[func];
		}
		

		return self;
	}
	
	return proxy();
}]);;
var appService = angular.module('AppService', []);
appService.service('localStore', ['$rootScope', function($rootScope) {
	this.save = function(key, value){
		localStorage.setItem(key, value);
	}

	this.remove = function(key) {
		localStorage.removeItem(key);
	}

	this.get = function(key) {
		value = localStorage.getItem(key);
		return value ? value : null;
	}

	this.clear = function() {
		localStorage.clear();
	}
}]).
service('ArticleService', ['httpService', function(httpService) {

	this.getArticle = function(callback) {
		httpService.apiGet("/api/articles/" + arguments[0]['id'], arguments);
	}
}]).
service('LessonLiveService', ['httpService', function(httpService) {

	this.createLiveTickets = function(callback) {
		httpService.apiPost("/api/lessons/" + arguments[0]['lessonId'] + "/live_tickets", arguments);
	}

	this.getLiveInfoByTicket = function(callback) {
		httpService.apiGet("/api/lessons/" + arguments[0]['lessonId'] + "/live_tickets/" + arguments[0]['ticket'], arguments);
	}

	this.getLiveReplay = function() {
		httpService.apiGet("/api/lessons/" + arguments[0]['id'] + "/replay", arguments);
	}

}]).
service('AnalysisService', ['httpService', function(httpService) {

	this.getCourseChartData = function(callback) {
		httpService.apiGet("/api/analysis/Course/learnDataByDay?courseId" + arguments[0]['courseId'], arguments);
	}
}]).
service('CategoryService', ['httpService', function(httpService) {

	this.getCategorieTree = function(parmars,callback) {
		httpService.newApiGet("/api/categories/" + arguments[0]['groupCode'],arguments);
	}
	}]).
service('LessonService', ['httpService', function(httpService) {

	this.getLesson = function(callback) {
		httpService.simpleGet("/mapi_v2/Lesson/getLesson", arguments);
	}

	this.getCourseLessons = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Lesson/getCourseLessons',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getApiLesson = function(params, callback) {
		httpService.apiGet("/api/lessons/" + arguments[0]['lessonId'] + "?courseId=" + arguments[0]["courseId"] + "&lessonId=" + arguments[0]['lessonId'], arguments);
	}
}]).
service('OrderService', ['httpService', function(httpService) {

	this.createOrder = function(params, callback) {
		httpService.simplePost("/mapi_v2/Order/createOrder", arguments);
	}

	this.payVip = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Order/payVip", arguments);
	}

	this.getPayOrder = function() {
		httpService.simplePost('/mapi_v2/Order/getPayOrder', arguments);
	}
}]).
service('NoteService', ['httpService', function(httpService) {

	this.getNote = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/getOneNote", arguments);
	}

	this.getNoteList = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getNoteList',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}
}]).
service('CouponService', ['httpService', function(httpService) {

	this.checkCoupon = function() {
		httpService.simplePost('/mapi_v2/Course/coupon', arguments);
	}
}]).
service('HomeworkManagerService', ['httpService', function(httpService) {

	this.teachingResult = function() {
		httpService.apiGet("/api/homework/manager/teaching", arguments);
	};

	this.showCheck = function() {
		httpService.apiGet("/api/homework/manager/check/" + arguments[0]['homeworkResultId'], arguments);
	}
}]).
service('ThreadManagerService', ['httpService', function(httpService) {

	this.questionResult = function() {
		httpService.apiGet("/api/thread/manager/question", arguments);
	}
}]).
service('UserService', ['httpService', 'applicationProvider', function(httpService, applicationProvider) {

	this.uploadAvatar = function(params, callback) {
		httpService.muiltPost({
			url : app.host + '/mapi_v2/User/uploadAvatar',
			data : params,
			success : callback
		});
	};

	this.updateUserProfile = function(params, callback) {
		httpService.simplePost("/mapi_v2/User/updateUserProfile", arguments);
	};

	this.getUserInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/User/getUserInfo", arguments);
	};

	this.follow = function(params, callback) {
		httpService.simplePost("/mapi_v2/User/follow", arguments);
	};

	this.unfollow = function(params, callback) {
		httpService.simplePost("/mapi_v2/User/unfollow", arguments);
	};

	this.searchUserIsFollowed = function(params, callback) {
		httpService.simpleGet("/mapi_v2/User/searchUserIsFollowed", arguments);
	}

	this.getUserTeachCourse = function(params,callback) {
		httpService.simpleGet("/mapi_v2/Course/getUserTeachCourse", arguments);
	}

	this.getLearningCourseWithoutToken = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/getLearningCourseWithoutToken", arguments);
	}

	this.getUserInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/User/getUserInfo", arguments);
	}

	this.smsSend = function(params, callback) {
		httpService.post({
			url : app.host + '/mapi_v2/User/smsSend',
			data : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getCourseTeachers = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/User/getCourseTeachers',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.regist = function(params, callback) {
		httpService.post({
			url : app.host + '/mapi_v2/User/regist',
			data : params,
			success : function(data, status, headers, config) {
				callback(data);
				if (data && !data.error) {
					applicationProvider.setUser(data.user, data.token);
				}
			},
			error : function(data) {
			}
		});
	}

	this.login = function(params, callback) {
		httpService.post({
			url : app.host + '/mapi_v2/User/login',
			data : params,
			success : function(data, status, headers, config) {
				callback(data);
				if (data && !data.error) {
					applicationProvider.setUser(data.user, data.token);
				}
			},
			error : function(data) {
			}
		});
	}

	this.logout = function(params, callback) {
		httpService.post({
			url : app.host + '/mapi_v2/User/logout',
			data : params,
			success : function(data, status, headers, config) {
				callback(data);
				applicationProvider.clearUser();
			},
			error : function(data) {
			}
		});
	}

}]).
service('ClassRoomService', ['httpService', function(httpService) {

	this.getThreads = function(params, callback) {
		httpService.apiGet("/api/classrooms/" + arguments[0]['classRoomId'] + "/threads", arguments);
	}

	this.getClassRoomPlayStatus = function(params, callback) {
		httpService.apiGet("/api/classroom_play/" + arguments[0]['classRoomId'] + "/status", arguments);
	}

	this.getClassRoomPlay = function(params, callback) {
		httpService.apiGet("/api/classroom_play/" + arguments[0]['classRoomId'], arguments);
	}

	this.search = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/search", arguments);
	}

	this.learnByVip = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/learnByVip", arguments);
	}

	this.sign = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/sign", arguments);
	}

	this.getTodaySignInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getTodaySignInfo", arguments);
	}

	this.getAnnouncements = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getAnnouncements", arguments);
	}

	this.unLearn = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/unLearn", arguments);
	}

	this.getTeachers = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getTeachers", arguments);
	}

	this.getStudents = function(params, callback) {
		httpService.apiGet("/api/classrooms/" + arguments[0]['classRoomId'] + "/members",arguments);
		// httpService.simpleGet("/mapi_v2/ClassRoom/getStudents", arguments);
	}

	this.getReviewInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getReviewInfo", arguments);
	}

	this.getReviews = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getReviews", arguments);
	}

	this.getClassRoomCourses = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getClassRoomCoursesAndProgress", arguments);
	}

	this.getLatestClassrooms = function(params, callback) {
		httpService.simplePost("/mapi_v2/ClassRoom/getLatestClassrooms", arguments);
	}

	this.getRecommendClassRooms = function(params, callback) {
		httpService.simplePost("/mapi_v2/ClassRoom/getRecommendClassRooms", arguments);
	}

	this.searchClassRoom = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getClassRooms", arguments);
	}

	this.getClassRoom = function(params, callback) {
		httpService.simpleGet("/mapi_v2/ClassRoom/getClassRoom", arguments);
	}

	this.getLearnClassRooms = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/ClassRoom/myClassRooms',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

}]).
service('QuestionService', ['httpService', function(httpService) {

	this.getCourseThreads = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getCourseThreads',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getThread = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getThread',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getThreadTeacherPost = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getThreadTeacherPost',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getThreadPost = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getThreadPost',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}
}]).
service('CourseService', ['httpService', function(httpService) {

	this.getThreads = function(params, callback) {
		httpService.apiGet("/api/courses/" + arguments[0]['courseId'] + "/threads", arguments);
	}

	this.getCourseThreads = function(params, callback) {
		httpService.simpleGet("/api/chaos_threads/getThreads", arguments);
	}

	this.getStudents = function(params, callback) {
		httpService.newApiGet("/api/courses/" + arguments[0]['courseId'] + "/members?role=student", arguments);
	}

	this.getSetStudents = function (params, callback) {
    httpService.newApiGet("/api/course_sets/" + arguments[3] + "/latest_members", arguments);
  }

	this.updateModifyInfo = function(params, callback) {
		httpService.simplePost("/mapi_v2/Course/updateModifyInfo", arguments);
	}

	this.getModifyInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/getModifyInfo", arguments);
	}

	this.getCourseNotices = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/getCourseNotices", arguments);
	}

	this.unLearnCourse = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/unLearnCourse", arguments);
	}

	this.vipLearn = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/vipLearn", arguments);
	}

	this.favoriteCourse = function(params, callback) {
		httpService.simplePost('/mapi_v2/Course/favoriteCourse', arguments);
	}

	this.unFavoriteCourse = function(params, callback) {
		httpService.simplePost('/mapi_v2/Course/unFavoriteCourse', arguments);
	}

	this.getCourseReviewInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/getCourseReviewInfo", arguments);
	}

	this.getReviews = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getReviews',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}
	this.getLiveCourses = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getLiveCourses',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getLearningCourse = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getLearningCourse',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}
	this.getLearnedCourse = function(params,callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getLearnedCourse',
			params : params,
			success : function (data,status,headers,config) {
				callback(data);
			},
			error : function(data){
			}
		});
}
	this.getAllUserCourses = function(params,callback){
		httpService.get({
			url : app.host + '/mapi_v2/Course/getLearningCourse',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
		httpService.get({
			url : app.host + '/mapi_v2/Course/getLearnedCourse',
			params : params,
			success : function (data,status,headers,config) {
				callback(data);
			},
			error : function(data){
			}
		});
}
	this.getFavoriteCourse = function(url, params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/' + url,
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.getAllLiveCourses = function(params, callback) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getAllLiveCourses',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
			}
		});
	}

	this.searchCourse = function (params, callback, error) {
		httpService.newApiGet ("/api/course_sets",arguments);
	}

	this.getCourse = function(params, callback) {
		httpService.simpleGet("/mapi_v2/Course/getCourse", arguments);
	}

	this.getCourses = function(params, callback, error) {
		httpService.get({
			url : app.host + '/mapi_v2/Course/getCourses',
			params : {
				limit : params.limit,
				start: params.start,
				categoryId : params.categoryId,
				sort : params.sort
			},
			success : function(data, status, headers, config) {
				callback(data);
			},
			error : function(data) {
				if (error) {
					error(data)
				}
			}
		});
	}
}]).
service('SettingService', ['httpService', function(httpService){
	this.getCourseSettings = function(params, callback){
		httpService.simpleGet('/api/setting/course', arguments);
	}
}]).
service('SchoolService', ['httpService', function(httpService) {

	this.getLiveLatestCourses = function(params, callback) {
		httpService.simpleGet("/mapi_v2/School/getLiveLatestCourses", arguments);
	}

	this.getLiveRecommendCourses = function(params, callback) {
		httpService.simpleGet("/mapi_v2/School/getLiveRecommendCourses", arguments);
	}

	this.getLatestCourses = function(params, callback) {
		httpService.simpleGet("/mapi_v2/School/getLatestCourses", arguments);
	}

	this.getVipPayInfo = function(params, callback) {
		httpService.simpleGet("/mapi_v2/School/getVipPayInfo", arguments);
	}

	this.getSchoolVipList = function(params, callback) {
		httpService.simpleGet('/mapi_v2/School/getSchoolVipList', arguments);
	}

	this.getSchoolPlugins = function(params, callback) {
		httpService.simpleGet('/mapi_v2/School/getSchoolPlugins', arguments);
	}

	this.getSchoolBanner = function(callback) {
		httpService.get({
			url : app.host + '/mapi_v2/School/getSchoolBanner',
			success : function(data, status, headers, config) {
				callback(data);
			}
		});
	}

	this.getRecommendCourses = function(params, callback) {

		httpService.get({
			url : app.host + '/mapi_v2/School/getRecommendCourses',
			params : params,
			success : function(data, status, headers, config) {
				callback(data);
			}
		});
	}
}]).
service('httpService', ['$http', '$rootScope', 'platformUtil', '$q', 'cordovaUtil', function($http, $rootScope, platformUtil, $q, cordovaUtil) {

	var self = this;
	this.filterCallback = function(data, callback) {
		if ("AuthToken is not exist." == data.message) {
			cordovaUtil.sendNativeMessage("token_lose", {});
			return;
		}

		if (data.error && "not_login" == data.error.name) {
			cordovaUtil.sendNativeMessage("token_lose", {});
			return;
		}
		callback(data);
	};

	this.getOptions = function(method, url, params, callback, errorCallback) {
		var options = {
			method : method,
			url : app.host + url,
			headers : { "token" : $rootScope.token },
			success : function(data, status, headers, config) {
				self.filterCallback(data, callback);
			},
			error : function(data) {
				if (errorCallback) {
					errorCallback(data);
				}
			}
		}

		if (method == "get") {
			options["params"] = params;
		} else if (method == "post") {
			options["data"] = params;
		}

		return options;
	};

	this.simpleRequest = function(method, url, params, callback, errorCallback) {
		var options = self.getOptions(method, url, params, callback, errorCallback);
		var http = $http(options).success(options.success);

		if (options.error) {
			http.error(options.error);
		} else {
			http.error(function(data) {
				console.log(data);
			});
		}
	}

	this.nativePost = function(options) {
		esNativeCore.post($q, options.url,  options.headers , options.data )
		.then(function(data) {
			self.filterCallback(angular.fromJson(data), options.success);
		}, function(error) {
			self.filterCallback(angular.fromJson(error), options.error);
		});
	};

	this.simplePost = function(url) {
		params  = arguments[1][0];
		callback = arguments[1][1];
		errorCallback = arguments[1][2];

		if (platformUtil.native) {
			var options = {
				url : app.host + url,
				headers : { "token" : $rootScope.token },
				data : params,
				success : callback,
				error : errorCallback
			}
			self.nativePost(options);
		} else {
			self.simpleRequest("post", url, params, callback, errorCallback);
		}
	};

	this.simpleGet = function(url) {
		params  = arguments[1][0];
		callback = arguments[1][1];
		errorCallback = arguments[1][2];

		self.simpleRequest("get", url, params, callback, errorCallback);
	};

	this.get = function(options) {
		options.method  = "get";
		options.headers = options.headers || {};
		options.headers["token"] = $rootScope.token;

		var http = $http(options).success(function(data) {
			self.filterCallback(data, options.success);
		});

		if (options.error) {
			http.error(options.error);
		} else {
			http.error(function(data) {
				console.log(data);
			});
		}
	}

	this.apiGet = function(url) {

		params  = arguments[1][0];
		callback = arguments[1][1];
		errorCallback = arguments[1][2];

		var options = self.getOptions("get", url, params, callback, errorCallback);
		options.headers['Auth-Token'] = options.headers['token'];
		options.headers['token'] = null;
		var http = $http(options).success(options.success);

		if (options.error) {
			http.error(options.error);
		} else {
			http.error(function(data) {
				console.log(data);
			});
		}
	}

  this.newApiGet = function(url) {
    params  = arguments[1][0];
    callback = arguments[1][1];
    errorCallback = arguments[1][2];
    var options = self.getOptions("get", url, params, callback, errorCallback);
    options.headers['Auth-Token'] = options.headers['token'];
    options.headers['Accept'] = 'application/vnd.edusoho.v2+json';
    options.headers['token'] = null;
    var http = $http(options).success(options.success);
    if (options.error) {
      http.error(options.error);
    } else {
      http.error(function(data) {
        console.log(data);
      });
    }
  }

	this.apiPost = function(url) {

		params  = arguments[1][0];
		callback = arguments[1][1];
		errorCallback = arguments[1][2];

		var options = self.getOptions("post", url, params, callback, errorCallback);
		options.headers['Auth-Token'] = options.headers['token'];
		options.headers['token'] = null;
		var http = $http(options).success(options.success);

		if (options.error) {
			http.error(options.error);
		} else {
			http.error(function(data) {
				console.log(data);
			});
		}
	}

	this.post = function(options) {

		options.method  = "post";
		options.headers = options.headers || {};
		options.headers["token"] = $rootScope.token;

		var angularPost = function(options) {
			var http = $http(options).success(function(data) {
				self.filterCallback(data, options.success);
			});
			if (options.error) {
				http.error(options.error);
			} else {
				http.error(function(data) {
					console.log(data);
				});
			}
		};

		if (platformUtil.native) {
			self.nativePost(options);
		} else {
			angularPost(options);
		}
	}

	this.muiltPost = function(options) {
		var headers = options.headers || {};
		headers["token"] = $rootScope.token;
		headers['Content-Type'] = undefined;

		var fd = new FormData();
		for (var key in options.data) {
			fd.append(key, options.data[key]);
		}

		$http.post(
			options.url,
			fd,
			{
            	transformRequest: angular.identity,
            	headers: headers
            }
        ).success(function(data){
        	options.success(data);
        }).error(function(error){
        	console.log(error);
        });
	}
}]);
;
Date.prototype.Format = function(fmt) 
{ //author: meizz 
  var o = { 
    "M+" : this.getMonth()+1,                 //月份 
    "d+" : this.getDate(),                    //日 
    "h+" : this.getHours(),                   //小时 
    "m+" : this.getMinutes(),                 //分 
    "s+" : this.getSeconds(),                 //秒 
    "q+" : Math.floor((this.getMonth()+3)/3), //季度 
    "S"  : this.getMilliseconds()             //毫秒 
  }; 
  if(/(y+)/.test(fmt)) 
    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length)); 
  for(var k in o) 
    if(new RegExp("("+ k +")").test(fmt)) 
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length))); 
  return fmt; 
}

app.filter('blockStr', ['$rootScope', function($rootScope) {
	return function(content, limitTo){
		if (!content) {
			return "";
		}
		content = content.replace(/<[^>]+>/g, "");
		if (limitTo && limitTo < content.length) {
			content = content.substring(0, limitTo);
			content += "...";
		}
		return content;
	};
}]).filter('array', ['AppUtil', function(AppUtil) {
	return function(num){
		return AppUtil.createArray(num);
	};
}]).filter('classRoomSignFilter', function() {
	return function(signInfo){
		if (!signInfo) {
			return "签到";
		}

		if (signInfo.isSignedToday) {
			var day = signInfo.userSignStatistics.keepDays ? signInfo.userSignStatistics.keepDays : 1;
			return "连续" + day + "天";
		}

		return "签到";
	};
}).
filter('lessonLearnStatus', function(){
	return function(progress) {
		if (progress.progressValue == 0) {
			return "还没开始学习";
		}

		if (progress.progressValue == 100) {
			return "已完结";
		}

		return "最近学习:" + progress.lastLesson.title;
	};
}).
filter('lessonLearnStatusTag', function(){
	return function(status, type) {
		console.log(status);
        if ("finished" == status && type != "live") {
        	return "<span class='ui-label green'>已完成</span>";
        };
        if ("learning" == status && type != "live") {
        	return "<span class='ui-label yellow'>学习中</span>";
        };
		return "";
	};
}).
filter('lessonType', function() {

	return function(lesson) {
		if (lesson.status == "unpublished") {
			return "<span class='ui-label gray'>未发布</span>";
		}
		if (lesson.type == "live") {
			if ("videoGenerated" == lesson.replayStatus) {
				return "<span class='ui-label gray' >回放</span>";
			}
			var returnStr = "";
			var startTime = lesson.startTime * 1000;
			var endTime = lesson.endTime * 1000;
			var currentTime = new Date().getTime();

			if (startTime > currentTime) {
				var showDate = new Date();
				showDate.setTime(startTime);
				returnStr = showDate.Format("MM月dd号 hh:mm");;
			} else if (startTime <= currentTime && endTime >= currentTime) {
				returnStr = "<span class='ui-label' >直播中</span>";
			}else if (endTime < currentTime) {
				if (lesson.replayStatus == 'generated' ) {
					returnStr = "<span class='ui-label gray' >回放</span>";
				} else {
					returnStr = "<span class='ui-label gray' >结束</span>";
				}
			}
			return returnStr;
		}
		if (lesson.free == 1) {
			return "<span class='ui-label green'>免费</span>";
		}
		return "";
	}
}).
filter('coverIncludePath', function() {
	return function(path) {
		return app.viewFloder + path;
	}
}).
filter('formatPrice', ['$rootScope', function($rootScope){

	return function(price) {
		if (price) {
			price = parseFloat(price);
			return price <= 0 ? "免费" : "¥" + price.toFixed(2);
		}
		return price;
	}
}]).
filter('formatCoinPrice', ['$rootScope', function($rootScope){

	return function(price, coinName) {
		if (price) {
			if (!coinName) {
				coinName = "";
			}
			price = parseFloat(price);
			return price <= 0 ? "免费" : price.toFixed(2) + coinName;
		}
		return price;
	}
}]).
filter('coverLearnProsser', ['$rootScope', function($rootScope){

	return function(course) {
		var lessonNum = course.lessonNum;
		var memberLearnedNum = course.memberLearnedNum;
		
		return {
			width : (memberLearnedNum / lessonNum) * 100 + "%"
		}
	}
}]).
filter('reviewProgress', function(){

	return function(progress, total) {
		if (total == 0) {
			return "0%";
		}
		return ( (progress / total) * 100 ).toFixed(0) + "%";
	}
}).
filter('formatChapterNumber', ['$rootScope', function($rootScope){

	return function(chapter) {
		var number = chapter.number;
		if (chapter.type == "label") {
			return "";
		}
		if (chapter.type != "chapter" && chapter.type != "unit") {
			return "课时:" + number + " ";
		}
		if(chapter.type == "chapter"){
			return chapter.chapter_name != null ? "第" + number + (chapter.chapter_name) : ""; 
		}
		if(chapter.type == "unit"){
			return chapter.part_name != null ? "第" + number + (chapter.part_name) : "";
		}
	}
}]).
filter('coverLearnTime', ['$rootScope', function($rootScope){
	return function(date) {
		if (! date) {
			return "还没开始学习";
		}

	  	var currentDates = new Date().getTime() - new Date(date).getTime(),
        currentDay = parseInt(currentDates / (60000*60) -1) //减去1小时
        if(currentDay >= 24*3){
            currentDay = new Date(date).Format("yyyy-MM-dd");
        }else if(currentDay >= 24){
            currentDay = parseInt(currentDay / 24) + "天前";
        }else if(currentDay == 0 ){
            var currentD = parseInt(currentDates / 60000);
            if(currentD >= 60){
                currentDay = "1小时前";
            }else{
                currentDay = currentD + "分钟前";
            }
        }else{
            currentDay = currentDay + "小时前";
        }

	  return currentDay;
	}
}]).
filter('coverArticleTime', ['$rootScope', function($rootScope){
	return function(date) {
		if (! date) {
			return "";
		}

	  	var currentDates = new Date().getTime() - new Date(date).getTime(),
        currentDay = parseInt(currentDates / (60000*60) -1) //减去1小时
        if(currentDay >= 24*3){
            currentDay = new Date(date).Format("yyyy-MM-dd");
        }else if(currentDay >= 24){
            currentDay = parseInt(currentDay / 24) + "天前";
        }else if(currentDay == 0 ){
            var currentD = parseInt(currentDates / 60000);
            if(currentD >= 60){
                currentDay = "1小时前";
            }else{
                currentDay = currentD + "分钟前";
            }
        }else{
            currentDay = currentDay + "小时前";
        }

	  return currentDay;
	}
}]).
filter('coverDiscountTime', ['$rootScope', function($rootScope){
	return function(endTime) {
		return new Date(new Date(endTime) - new Date()).Format("d天h小时m分钟");
	}
}]).
filter('coverViewPath', ['$rootScope', function($rootScope){
	return function(path) {
		return app.viewFloder + path;
	}
}]).
filter('coverNoticeIcon', ['$rootScope', function($rootScope){
	return function(type) {
		return app.viewFloder + "img/course_notice.png";
	}
}]).
filter('coverGender', ['$rootScope', function($rootScope){

	return function(gender) {
		switch (gender) {
			case "male":
				return "男士";
			case "female":
				return "女士";
			default:
				return "保密";

		}
	}
}]).
filter('coverPic', ['$rootScope', function($rootScope){

	return function(src) {
		if (src) {
			return src;
		}
		return app.viewFloder  + "img/course_default.jpg";
	}
}]).
filter('coverDiscount', ['$rootScope', function($rootScope){

	return function(type, discount) {
		if (type == "free") {
			return "限免";
		}
		var discountNum = parseFloat(discount);
		return discountNum + "折";
	}
}]).
filter('coverAvatar', ['$rootScope', function($rootScope){

	return function(src) {
		if (src) {
			if (src.indexOf("http://") == -1) {
				src = app.host + src;
			}
			return src;
		}
		return app.viewFloder  + "img/avatar.png";
	}
}]).
filter('questionResultStatusColor', function() {

	return function(status) {
		if ("noAnswer" == status) {

		}

		return "wrong";
	}
}).
filter('questionResultStatusIcon', function() {

	return function(status) {
		if ("noAnswer" == status) {

		}

		return "icon-wrong";
	}
}).
filter('fillAnswer', function() {

	return function(answer, index) {
		if (!answer) {
			return "";
		}

		if (answer[index]) {
			return "selected";
		}
	}
}).
filter('coverUserRole', function(AppUtil){

	return function(roles) {
		if (AppUtil.inArray("ROLE_SUPER_ADMIN", roles) != -1) {
			return "超管";
		};

		if (AppUtil.inArray("ROLE_ADMIN", roles) != -1) {
			return "管理员";
		};

		if (AppUtil.inArray("ROLE_TEACHER", roles) != -1) {
			return "教师";
		};
		return "学生";
	}
}).
filter('isTeacherRole', function(AppUtil){

	return function(roles) {
		if (AppUtil.inArray("ROLE_TEACHER", roles) != -1) {
			return true;
		}

		if (AppUtil.inArray("teacher", roles) != -1) {
			return true;
		}
		return false;
	}
}).
filter('coverLessonLengthTime', ['AppUtil', function(AppUtil){
	return function(timeStr) {
		time = parseInt(timeStr);
		if (! time || time == 0) {
			return "";
		}
		var minutes = Math.floor(time/(60));

		if (minutes <= 0) {
			if (time < 10) {
				time = "0" + time;
			}
			return AppUtil.formatString("00:%1", time);
		}
		time = time % 60;
		if (minutes < 10) {
			minutes = "0" + minutes;
		}
		if (time < 10) {
			time = "0" + time;
		}
		return AppUtil.formatString("%1:%2", minutes, time);
	}
}]).
filter('lessonIcon', function(){

	return function(lesson) {
		switch (lesson.type) {
			case "video" :
				return "icon-lessonvideo";
			case "ppt" :
				return "icon-lessonppt-copy";
			case "document" :
				return "icon-lessondoc";
			case "audio" :
				return "icon-lessonaudio";
			case "text" :
				return "icon-lessonpic";
			case "flash" :
				return "icon-lessonflash";
			case "testpaper" :
				return "icon-exam-lesson";
			case "live" :
				return "icon-lessonlive";
			default:
				return "";
		}
	}
});;
app.directive('onElementReadey', function ($parse, $timeout) {
    return {
        restrict: 'A',
        link : function(scope, element, attrs) {
          $timeout(function() {
            $parse(attrs.onElementReadey)(scope);
           }, 100);
        }
    };
}).
directive('uiServicePanel', function($timeout) {
  return {
        restrict: 'A',
        link : function(scope, element, attrs) {
          var list = element[0].querySelector(".ui-list");
          var btn = element[0].querySelector(".service-btn");
          var expandIcon = angular.element(element[0].querySelector(".service-icon"));

          var btnElement = angular.element(btn);
          btnElement.on('click', function(e) {
            
            var expand = btnElement.attr("expand");
            btnElement.attr("expand", "true" == expand ? "false" : "true");
            expandIcon.css("-webkit-transform", ("true" == expand ? "rotate(-180deg)" : "rotate(0)"));

            var length = list.children.length;
            for (var i = 2; i < length; i++) {
              list.children[i].style.display = ("true" == expand ? 'none' : 'block');
            };
          });
          //$(titleLabel).animate({ 'left' : left + 'px' }, 500, 'ease-out');
        }
    };
}).
directive('uiAutoPanel', function () {
  return {
        restrict: 'A',
        link : function(scope, element, attrs) {
          element.attr("close", "true");
          var autoBtn = element[0].querySelector(".ui-panel-autobtn");
          var content = element[0].querySelector(".ui-panel-content");

          scope.$watch(attrs.data, function(newValue) {
            initAutoBtn();
          });

          function initAutoBtn() {

            if (200 > content.offsetHeight) {
              autoBtn.style.display = 'none';
              return;
            }
            content.style.height = '200px';
            var expand = angular.element(autoBtn.querySelector(".autobtn-icon"));
            var autoBtnText = autoBtn.querySelector(".autobtn-text");
            
            angular.element(autoBtn).on('click', function() {
              var isClose = element.attr("close");
              if ("true" == isClose) {
                  autoBtnText.innerText = "收起";
                  content.style.overflow = 'auto';
                  content.style.height = 'auto';
                  expand.removeClass("icon-expandmore");
                  expand.addClass("icon-expandless");
                  element.attr("close", "false");
              } else {
                  autoBtnText.innerText = "展开";
                  content.style.overflow = 'hidden';
                  content.style.height = '200px';
                  expand.addClass("icon-expandmore");
                  expand.removeClass("icon-expandless");
                  element.attr("close", "true");
              }
            });
          }
        }
    };
}).
directive('uiTab', function ($parse) {
  return {
    restrict: 'A',
    link : function(scope, element, attrs) {

          var self = this;
          var heightVar = attrs.height ? attrs.height : "100%";
          var scroller = element[0].querySelector('.ui-tab-content');
          var nav = element[0].querySelector('.ui-tab-nav');
          if (attrs.canTopFloat == "true") {
            console.log("clone tab");
            var cloneTabNav = createTabNavFromClone();
            $("body").after(cloneTabNav);
          }

          function createTabNavFromClone() {
            var clone = $(nav).clone();
            clone.addClass("ui-tab-navclone");
            clone.css("top", "-44px");
            clone.css("position", "fixed");

            return clone[0];
          };

          function itemOnLoadListener(currentItem) {
            var isFirstRun = currentItem.attr("isFirstRun");
            var itemOnLoad = currentItem.attr("ng-onload");
            if ("true" != isFirstRun) {
              if (itemOnLoad) {
                $parse(itemOnLoad)(scope);
              }
              
              currentItem.attr("isFirstRun", "true");
            }
          }

          if ("empty"  != attrs.select) {
            var childrenIndex = 0;
            var childrenElement;
            for (var i = 0; i < nav.children.length; i++) {
              if (angular.element(nav.children[i]).hasClass('current')) {
                childrenIndex = i;
                break;
              }
            };

            angular.element(scroller.children[childrenIndex]).addClass('current');
            angular.element(nav.children[childrenIndex]).addClass('current');
            var cloneTabNavClild = $(cloneTabNav).children().get(childrenIndex);
            $(cloneTabNavClild).addClass("current");
            itemOnLoadListener(angular.element(scroller.children[childrenIndex]));
          }

          this.currentPage = 0;
          scroller.style.width = "100%";

          this.itemWidth = scroller.children[0].clientWidth;
          this.scrollWidth = this.itemWidth * this.count;

          function changeTabContentHeight(height) {
              var tabContent = element[0].querySelector('.ui-tab-content');
              $(tabContent).height(height);
          }

          function tabItemClick(item) {
            var currentItem = $(item);
            var tagetHasCurrent = currentItem.hasClass('current');
            var tempCurrentPage = self.currentPage;
            self.currentPage = currentItem.index();

            $(cloneTabNav).children().removeClass('current');
            $(nav).children().removeClass('current');
            $(scroller).children().removeClass('current');

            if (tempCurrentPage == self.currentPage && "empty"  == attrs.select && tagetHasCurrent) {
              changeTabContentHeight(0);
              scope.$emit("tabClick", {
                index : self.currentPage,
                isShow : false
              });
              return;
            }

            var currentScroller = angular.element(scroller.children[self.currentPage]);
            currentItem.addClass('current');
            var cloneTabNavClild = $(cloneTabNav).children().get(self.currentPage);
            $(cloneTabNavClild).addClass("current");
            currentScroller.addClass("current");
            itemOnLoadListener(currentScroller);
            changeTabContentHeight(heightVar);
            scope.$emit("tabClick", {
                index : self.currentPage,
                isShow : true
            });

            $("body").scrollTop(0);
          };

          angular.forEach($(cloneTabNav).children(), function(item) {
            angular.element(item).on("click", function(e) {
              tabItemClick(nav.children[$(item).index()]);
            });
          });

          angular.forEach(nav.children, function(item) {
            angular.element(item).on("click", function(e) {
              tabItemClick(item);
            });
          });

          if ("empty"  == attrs.select) {
              scope.$on("closeTab", function(event, data) {
                angular.element(scroller.children[self.currentPage]).removeClass('current');
                angular.element(nav.children[self.currentPage]).removeClass('current');
                changeTabContentHeight(0);
                scope.$emit("tabClick", {
                    index : self.currentPage,
                    isShow : false
                });
              });
          }
    }
  }
}).
directive('imgError', function($timeout) {
  return {
    restrict: 'A',
    compile: function(tElem, tAttrs) {
            return {
                post: function postLink(scope, element, attributes) {
                  var errorSrc = "";
                  switch (attributes.imgError) {
                    case "avatar":
                      errorSrc = app.viewFloder  + "img/avatar.png";
                      break;
                    case "course":
                      errorSrc = app.viewFloder  + "img/default_course.jpg";
                      break;
                    case "vip":
                      errorSrc = app.viewFloder  + "img/vip-bage-default.png";
                      break;
                    case "classroom":
                      errorSrc = app.viewFloder  + "img/default_class.jpg";
                      break;
                  }

                  element.attr('src', errorSrc);
                  element.on("error", function(e) {
                    element.attr("src", errorSrc);
                    element.on("error", null);
                  });

                  if (attributes.imgSrc != null
                    && "classroom" == attributes.imgError
                    && attributes.imgSrc.indexOf("course-large.png") != -1) {
                    return;
                  }
                  $timeout(function() {
                    element.attr('src', attributes.imgSrc);
                  }, 100);
                }
            };
    }
  }
}).
directive('ngImgShow', function() {
  return {
    restrict: 'A',
    link : function(scope, element, attrs) {
      setTimeout(function() {
        var imageArray = [];
        angular.forEach(element[0].getElementsByTagName("img"), function(item, i) {
          imageArray.push(item.src);
          item.alt = i;
          item.addEventListener("click", function() {
            esNativeCore.showImages(this.alt, imageArray);
          });
        });
      }, 200);   
    }
  }
}).
directive('back', function(cordovaUtil, $state) {
  return {
    restrict: 'A',
    compile: function(tElem, tAttrs) {
            return { 
                post: function postLink(scope, element, attributes) {

                  element.on("click", function(){
                    if (attributes["back"] == "go") {
                      cordovaUtil.backWebView();
                      return;
                    }
                    if (attributes["back"] == "close") {
                      if (scope.close) {
                        scope.close();
                      } else {
                        cordovaUtil.closeWebView();
                      }
                      return;
                    }
                    $state.go("slideView.mainTab");
                  });
                }
            };
    }
  }
}).
directive('ngHtml', function($window, $state) {
  return {
    restrict: 'A',
    compile: function(tElem, tAttrs) {
            return { 
                post: function postLink(scope, element, attributes) {
                  scope.$watch(attributes.ngHtml, function(newValue) {
                    element.html(newValue);
                  });
                }
           };
    }
  }
}).
directive('uiPop', function($window) {
  return {
    restrict: 'A',
    compile: function(tElem, tAttrs) {
            return { 
                post: function postLink(scope, element, attributes) {

                    function changePopStatus() {
                      scope.$apply(function() {
                        scope.isShowMenuPop = ! scope.isShowMenuPop;
                      });
                    }

                    var popBtn = element[0].querySelector(".ui-pop-btn");
                    var popBg = element[0].querySelector(".ui-pop-bg");

                    popBg.style.width = $window.innerWidth + "px";
                    popBg.style.height = $window.innerHeight + "px";
                    angular.element(popBg).on("click", function(e) {
                      changePopStatus();
                    });

                    angular.element(popBtn).on("click", function(e) {
                      changePopStatus();
                    });
                }
           };
    }
  }
}).
directive('uiBar', function() {
  return {
    restrict: 'A',
    link : function(scope, element, attrs) {
      var toolEL = element[0].querySelector(".bar-tool");
      var titleEL = element[0].querySelector(".title");
      
      var toolELWidth = toolEL ? toolEL.children.length * 48 : 48;
      toolELWidth = toolELWidth < 48 ? 48 : toolELWidth;
      titleEL.style.paddingRight = toolELWidth + "px";
      titleEL.style.paddingLeft = toolELWidth + "px";
    }
  }
}).
directive('ngHref', function($window) {
  return {
    restrict: 'A',
    compile: function(tElem, tAttrs) {
            return function ngEventHandler(scope, element, attr) {
              element.on("click", function(e) {
                var url = [$window.location.origin, $window.location.pathname, attr.ngHref].join("");
                if (scope.platform.native) {
                  esNativeCore.openWebView(url);
                  return;
                }
                $window.location.href = url;
              });
            };
    }
  }
}).
directive('uiScroll', function($parse, platformUtil) {
  return {
    restrict: 'A',
    link : function(scope, element, attrs) {
      
      function processScrollByAndroid(clone, self, headHeight) {
        if (!clone) {
            return;
        }

        if (!self.isTop && element[0].scrollTop > headHeight) {
          self.isTop = true;
          clone.css("top", "44px");
          return;
        }
        if (self.isTop && element[0].scrollTop < headHeight) {
          self.isTop = false;
          clone.css("top", "-44px");
        }
      };

      function processScrollByiOS(uiTab, tabContent, self, headHeight) {
        if (!uiTab) {
            return;
        }

        if (!self.isTop && element[0].scrollTop > headHeight) {
          self.isTop = true;
          uiTab.css("position", "fixed");
          uiTab.css("top", "44px");
          tabContent.css("paddingTop", "44px");
          return;
        }
        if (self.isTop && element[0].scrollTop < headHeight) {
          self.isTop = false;
          uiTab.css("position", "relative");
          uiTab.css("top", "0");
          tabContent.css("paddingTop", "0");
        }
      };

      function bindTopScrollListener() {
        var uiTab = element[0].querySelector(".ui-tab-nav");
        var headBody = element[0].querySelector(".course-head-body");

        if (!uiTab) {
          return;
        }
        var clone = $(".ui-tab-navclone");
        var tabContent = $(element[0].querySelector(".ui-tab-content"));

        var self = this;
        self.isTop = false;
        var headHeight = headBody.offsetHeight;
        element.on("scroll", function() {
          processScrollByAndroid(clone, self, headHeight);
        });
      };

      bindTopScrollListener();

      scope.$watch(attrs.data, function(newValue) {
          function onScrollListener() {
            var scrollHeight = element[0].scrollHeight;
            var scrollTop = element[0].scrollTop;
            var clientHeight = element[0].clientHeight;

            if (attrs.onScroll) {
              scope.headTop = uiHead.offsetHeight;
              scope.scrollTop = scrollTop;
              $parse(attrs.onScroll)(scope);
            }
            if ( !scope.isLoading && ( (scrollTop + clientHeight) >= scrollHeight ) ) {
              scope.isLoading = true;
              $parse(attrs.onInfinite)(scope, { successCallback : function() {
                scope.isLoading = false;
              } });
            }
          }
          var uiHead = element[0].querySelector(".ui-details-head");
          if (newValue) {
                if (angular.isArray(newValue) && newValue.length == 0) {
                  return;
                }
              
                element.on("scroll", function() {
                  onScrollListener();
                });
          } else {
            element.off("scroll");
          }

      });
      
    }
  }
}).
directive('uiSliderBox', function($parse) {
  return {
    restrict: 'A',
    link : function(scope, element, attrs) {
          scope.$watch(attrs.uiSliderBox, function(newValue) {
            if (newValue && newValue.length > 0) {
                initSlider();
                if (attrs.onLoad) {
                  $parse(attrs.onLoad)(scope, element);
                }
            }
          });

          if ("true" != attrs.auto && element[0].clientWidth) {
            element.css('height', (element[0].clientWidth / 1.9) + "px");
          }
          
          function initSlider () {
              var slider = new fz.Scroll('.' + attrs.slider, {
                  role: 'slider',
                  indicator: true,
                  autoplay: false,
                  interval: 3000
              });

              slider.on('beforeScrollStart', function(fromIndex, toIndex) {
                if (attrs.scrollChange) {
                  scope.scrollIndex = toIndex;
                  $parse(attrs.scrollChange)(scope);
                }
              });

              slider.on('scrollEnd', function() {

              });
          }
          
    }
  }
}).
directive('slideIndex', function() {
  return {
    restrict: 'A',
    link : function(scope, element, attrs) {
          var total = 0;
          var $currentIndex = 0;
          scope.slideHasChanged = function($index) {
            $currentIndex = $index;
            changeSlidePointStatus();
          }

          scope.$watch("banners", function(newValue) {
            if (newValue && newValue.length > 0) {
                total = newValue.length;
                initSlideIndex();
            }
          });
          
          function changeSlidePointStatus()
          {
            angular.forEach(element[0].querySelectorAll('.point'), function(item, index){

              if (index == $currentIndex) {
                item.classList.add("active");
              } else {
                item.classList.remove("active");
              }
            });
          }

          function initSlideIndex() {
                var points = "";
            
                for (var i = 0 ; i < total; i++) {
                  if (i == $currentIndex) {
                    points += "<span class='point active'></span>";
                  } else {
                    points += "<span class='point'></span>";
                  }
                  
                };

                element.append("<p class='slide-index'>" + points + "</p>");
          }
    }
  }
}).
directive('lazyLoad', function () {
  return function(scope, elm, attr) {
            echo.init({
            root:elm[0],
            offset: 100,
            throttle: 250,
            unload: false,
            callback: function (element, op) {

            }
        });
    }
}).
directive('modal', function () {
  return {
    restrict: 'EA',
    priority : 10000,
    controller : function($scope, $element) {
    },
    link : function(scope, element, attrs) {
      element.addClass("ui-modal");
      element.addClass("item");
      element.on('click', function(event) {
        scope.$emit("closeTab", {});
        $(".ui-scroller").css("overflow","scroll");
      });

      scope.$on("tabClick", function(event, data) {
        if (!data.isShow) {
          $(".ui-scroller").css("overflow","scroll");
          return;
        }

        $(".ui-scroller").css("overflow","hidden");
      });

    }
  }
}).
directive('listEmptyView', function (AppUtil, $parse) {
  return {
    restrict: 'EA',
    link : function(scope, element, attrs) {
      var html = '<div class="list-empty"><a> <i class="icon iconfont icon-%1"></i> <span>%2</span> </a></div>';
      title = attrs.isFunction ? $parse(attrs.title)(scope) : attrs.title;
      html = AppUtil.formatString(html, attrs.icon || "ebook", title);

      scope.$watch(attrs.data, function(newValue) {
        if (newValue && newValue.length == 0) {
          element.html(html);
        } else {
          element.html("");
        }
      });
    }
  }
}).
directive('categoryTree', function () {
    return {
        restrict: 'E',
        scope: {  
            data: '=data',
            listener : '=listener'
        }, 
        templateUrl: app.viewFloder + 'view/category_tree.html', 

        link : function(scope, element, attrs) {

          function initCategory($scope) {
            var categoryCols = [];
            var categoryTree = $scope.data;
            for (var i = 2; i >= 0; i--) {
                categoryCols[i] = [];
            };

            var getRootCategory = function(categoryId) {
              return {
                name : "全部",
                id : categoryId ? categoryId : 0
              }
            };

            categoryCols[0] = [getRootCategory()].concat(categoryTree);
            $scope.categoryCols = categoryCols;

            var changeItemBG = function(item) {
              var parentNode = item.parentNode;
              if (!parentNode) {
                return;
              }

              angular.forEach(parentNode.children, function(item) {
                angular.element(item).css("background", "none");
              });
            };

            $scope.selectCategory = function($event, category) {
                    
                    changeItemBG($event.srcElement.parentNode);
                    angular.element($event.srcElement.parentNode).css("background", "#ccc");
                    if (category.children && category.children.length > 0) {
                      for (var i = $scope.categoryCols.length- 1; i >= category.depth; i--) {
                          $scope.categoryCols[i] = [];
                      };
                      var categoryColIndex = category.depth;
                      if (category.depth > 2) {
                        categoryColIndex = 2;
                      }
                      $scope.categoryCols[categoryColIndex] = [getRootCategory(category.id)].concat(category.children);
                      $event.stopPropagation();
                    } else {
                      $scope.listener(category);
                    }
            };
          }

          scope.$watch("data", function(newValue) {
            if (newValue) {
                initCategory(scope);
            }
          });
        }
    };
});;
var appProvider = angular.module('AppProvider', []);
appProvider.provider('applicationProvider', function() {

	var self = this;
	this.$get = function(localStore, $rootScope, $q, cordovaUtil) {
		var application = {
			host : null,
			user : null,
			token : null
		};

		application.setHost = function(host){
			this.host = host;
		}

		application.init = function(host) {
			application.setHost(host);
			cordovaUtil.getUserToken($q).then(function(data) {
				application.user = data.user;
				application.token = data.token;
      	application.updateScope($rootScope);
			});
		}

		application.clearUser = function() {
			this.user = null;
			this.token = null;
			$rootScope.user = null;
			$rootScope.token = null;
			cordovaUtil.clearUserToken();
		}

		application.setUser = function(user, token) {
			this.user = user;
			this.token = token;
			this.updateScope($rootScope);
			cordovaUtil.saveUserToken(user, token);
		}

		application.updateScope = function($scope) {
			$scope.user = application.user;
			$scope.token = application.token;
		}
	    	return application;
	  }
});

appProvider.provider('appRouter', function($stateProvider) {

	this.initPlugin = function($stateProvider) {
		$stateProvider.state('article', {
          url: "/article/:id",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/article.html",
              controller : ArticleController
            }
          }
        });
	};

	this.init = function() {
    var routingConfig = app.routingConfig || {};

    var state = $stateProvider.state;
    $stateProvider.state = function(name, args) {
      if (routingConfig.hasOwnProperty(name)) {
        args = routingConfig[name];
      }
      return state.call($stateProvider, name, args);
    };
    
		$stateProvider.state("slideView",{
            abstract: true,
            views : {
                "rootView" : {
                    templateUrl : app.viewFloder  + 'view/main.html',
                    controller : AppInitController
                }
            }
        }).state("slideView.mainTab",{
        	url : "/index",
        	views : {
          		"menuContent" : {
            		templateUrl : app.viewFloder  + 'view/main_content.html',
            		controller : FoundTabController
          	}
       }
       });

        $stateProvider.state('courseList', {
          url: "/courselist/:type/:categoryId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course_list.html",
              controller: CourseListController
            }
          }
        }).state('courseList.type', {
          url: "/type",
          views: {
            'courselist-content': {
              templateUrl: app.viewFloder  + "view/courselist_type.html"
            }
          }
        }).state('courseList.sort', {
          url: "/sort",
          views: {
            'courselist-content': {
              templateUrl: app.viewFloder  + "view/courselist_sort.html"
            }
          }
        });

        $stateProvider.state('classRoomList', {
          url: "/classroomlist/:categoryId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/classroom_list.html",
              controller: ClassRoomListController
            }
          }
        });

        $stateProvider.state('login', {
          url: "/login/:goto",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/login.html",
              controller: LoginController
            }
          }
        }).state('regist', {
          url: "/regist",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/regist.html",
              controller: RegistController
            }
          }
        });

        $stateProvider.state('myinfo', {
          url: "/myinfo",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/myinfo.html",
              controller: MyInfoController
            }
          }
        });

        $stateProvider.state('mylearn', {
          url: "/mylearn",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/mylearn.html",
              controller : MyLearnController
            }
          }
        });

        $stateProvider.state('myfavorite', {
          url: "/myfavorite",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/myfavorite.html"
            }
          }
        })

        $stateProvider.state('setting', {
          url: "/setting",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/setting.html",
              controller : SettingController
            }
          }
        });
        $stateProvider.state('question', {
          url: "/question/:courseId/:threadId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/question.html",
              controller : QuestionController
            }
          }
        });

        $stateProvider.state('note', {
          url: "/note/:noteId/",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/note.html",
              controller : NoteController
            }
          }
        });

        $stateProvider.state('course', {
          url: "/course/:courseId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course.html",
              controller : CourseController
            }
          }
        });

        $stateProvider.state('classroom', {
          url: "/classroom/:classRoomId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/classroom.html",
              controller : ClassRoomController
            }
          }
        });

        $stateProvider.state('courseDetail', {
          url: "/coursedetail/:courseId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course_detail.html",
              controller : CourseDetailController
            }
          }
        });

        $stateProvider.state('teacherlist', {
          url: "/teacherlist/:targetType/:targetId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/teacher_list.html",
              controller : TeacherListController
            }
          }
        });

        $stateProvider.state('studentlist', {
          url: "/studentlist/:targetType/:targetId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/teacher_list.html",
              controller : StudentListController
            }
          }
        });

        $stateProvider.state('coursePay', {
          url: "/coursepay/:targetId/:targetType",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course_pay.html",
              controller : CoursePayController
            }
          }
        });

        $stateProvider.state('courseCoupon', {
          url: "/coursecoupon/:courseId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/coupon.html",
              controller : CourseCouponController
            }
          }
        });

        $stateProvider.state('viplist', {
          url: "/viplist",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/vip_list.html",
              controller : VipListController
            }
          }
        });

        $stateProvider.state('courseSetting', {
          url: "/coursesetting/:courseId/:isLearn",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course_setting.html",
              controller : CourseSettingController
            }
          }
        });

        $stateProvider.state('vipPay', {
          url: "/vippay/:levelId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/vip_pay.html",
              controller : VipPayController
            }
          }
        });

        $stateProvider.state('courseNotice', {
          url: "/coursenotice/:targetType/:targetId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course_notice.html",
              controller : CourseNoticeController
            }
          }
        });

        $stateProvider.state('courseReview', {
          url: "/coursereview/:targetType/:targetId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/course_review.html",
              controller : CourseReviewController
            }
          }
        });

        $stateProvider.state('userInfo', {
          url: "/userinfo/:userId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/user_info.html",
              controller : UserInfoController
            }
          }
        });

        $stateProvider.state('lesson', {
          url: "/lesson/:courseId/:lessonId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/lesson.html",
              controller : SingleLessonController
            }
          }
        });
        $stateProvider.state('search', {
          url: "/search",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/search.html",
              controller : SearchController
            }
          }
        });

        $stateProvider.state('todolist', {
          url: "/todolist/:courseId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/todolist.html",
              controller : TeacherTodoListController
            }
          }
        });

        $stateProvider.state('homeworkCheck', {
          url: "/homeworkcheck/:homeworkResultId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/homework_check.html",
              controller : HomeworkCheckController
            }
          }
        });

        $stateProvider.state('teachingThreadList', {
          url: "/teaching/threadlist/:courseId",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/teaching_thread_list.html",
              controller : ThreadTeachingController
            }
          }
        });

        $stateProvider.state('searchCourseResult', {
          url: "/search/course/:search",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/search_course_result.html",
              controller : SearchCourseResultController
            }
          }
        });

        $stateProvider.state('searchClassRoomResult', {
          url: "/search/classroom/:search",
          views: {
            'rootView': {
              templateUrl: app.viewFloder  + "view/search_classroom_result.html",
              controller : SearchClassRoomResultController
            }
          }
        });

	    this.initPlugin($stateProvider);
	}

	this.$get = function() {
		return {};
	}
});;
app.controller('AppInitController', ['$scope', '$state', 'sideDelegate', 'SchoolService', AppInitController]);

function baseController($scope)
{
	this.getService = function(name) {
		return angular.injector(["AppService", "ng"]).get(name);
	}
}

function AppInitController($scope, $state, sideDelegate, SchoolService)
{	
	$scope.toggle = function() {
	   	sideDelegate.toggleMenu();
	};

	$scope.showMyView = function(state) {
		if ($scope.user) {
			$state.go(state);
		} else {
			$state.go("login");
		}
	}

	SchoolService.getSchoolPlugins(null, function(data) {
		$scope.plugins = data;
	});
};
app.controller('ArticleController', ['$scope', '$state', '$stateParams', 'cordovaUtil', 'ArticleService', ArticleController]);

function ArticleController($scope, $state, $stateParams, cordovaUtil, ArticleService)
{	
	var self = this;

	this.filterContent = function(content, limit) {
		content = content.replace(/<\/?[^>]*>/g,'');
		content = content.replace(/[\r\n\s]+/g,'');
		if (content.length > limit) {
	       content = content.substring(0, limit);
	    }
	    
	    return content;
	}

	$scope.init = function() {
		$scope.showLoad();
		ArticleService.getArticle({
			id : $stateParams.id
		}, function(data) {
			$scope.hideLoad();
			$scope.article = data;
		});
	};

	$scope.refresh = function(popScope) {
		$scope.init();
		popScope.isShowMenuPop = !popScope.isShowMenuPop;
	}

	$scope.share = function() {
		cordovaUtil.share(
	        app.host + "/article/" + $scope.article.id, 
	        $scope.article.title, 
	        self.filterContent($scope.article.body, 20), 
	        $scope.article.picture
	    );  
	}

	$scope.redirect = function() {
		var url = [app.rootPath, "#article/", $scope.article.id ].join("");
		cordovaUtil.redirect({
			type : "news.redirect",
			fromType : "news",
			id : $scope.article.id,
			title : $scope.article.title,
			image : $scope.article.picture,
			content : self.filterContent($scope.article.body, 20),
			url : url,
			source : "self"
		});
	}
};
app.controller('ClassRoomController', ['$location', '$scope', '$stateParams', 'ClassRoomService', 'AppUtil', '$state', 'cordovaUtil', 'ClassRoomUtil', ClassRoomController]);
function ClassRoomController($location, $scope, $stateParams, ClassRoomService, AppUtil, $state, cordovaUtil, ClassRoomUtil)
{
  var self = this;

  this.initTagIndex = function() {
      $scope.tabIndex = $location.$$hash ? $location.$$hash : 0;
      $scope.$on("tabClick", function(event, data) {
        $location.hash(data.index);
      });
  };

  this.loadClassRoom = function() {
    $scope.showLoad();
    ClassRoomService.getClassRoom({
      id : $stateParams.classRoomId
    }, function(data) {
      $scope.ratingArray = AppUtil.createArray(5);
      $scope.vipLevels = data.vipLevels;
      $scope.member = data.member;
      $scope.isFavorited = data.userFavorited;
      $scope.discount = data.discount;

      $scope.classRoomView = app.viewFloder + (data.member ? "view/classroom_learn.html" : "view/classroom_no_learn.html");
      $scope.classRoom = ClassRoomUtil.filterClassRoom(data.classRoom);
      $scope.hideLoad();
    });
  };
  $scope.gotoNativeDetailClassroomPage = function (classroomId) {

      esNativeCore.openNativeClassroomDetailPage(classroomId);
  };

  $scope.loadClassRoomDetail = function() {
    $scope.classRoomDetailContent = $scope.classRoom.about;
  }

  $scope.loadReviews = function(){
      ClassRoomService.getReviews({
        classRoomId : $stateParams.classRoomId,
        limit : 1
      }, function(data) {
        $scope.reviews = data.data;
      });
  };

  $scope.loadStudents = function() {
    ClassRoomService.getStudents({
      classRoomId : $stateParams.classRoomId,
      limit : 3
    }, function(data) {
      $scope.students = data.resources;
    });
  };

  $scope.loadTeachers = function() {
    ClassRoomService.getTeachers({
      classRoomId : $stateParams.classRoomId,
    }, function(data) {
      if (data && data.length > 1) {
        var length = data.length;
        for (var i = 2; i < length; i++) {
          data.pop();
        };
      }

      $scope.teachers = data;
    });
  };

  $scope.unLearn = function(reason) {
      $scope.showLoad();
      ClassRoomService.unLearn({
        reason : reason,
        targetType : "classroom",
        classRoomId : $stateParams.classRoomId
      }, function(data) {
        $scope.hideLoad();
        if (! data.error) {
          window.location.reload();
        } else {
          $scope.toast(data.error.message);
        }
      });
    }

    $scope.showStudents = function() {
      cordovaUtil.openWebView(app.rootPath + "#/studentlist/classroom/" + $stateParams.classRoomId);
    };
    
     $scope.showCourseSetting = function() {
      cordovaUtil.showCourseSetting($stateParams.classRoomId,"classroom");
    };

    $scope.shardClassRoom = function() {
      function filterContent(content, limit) {

          content = content.replace(/<\/?[^>]*>/g,'');
          content = content.replace(/[\r\n\s]+/g,'');
          if (content.length > limit) {
               content = content.substring(0, limit);
            }
            
            return content;
        }

      var about = $scope.classRoom.about;

      cordovaUtil.share(
        app.host + "/classroom/" + $scope.classRoom.id, 
        $scope.classRoom.title, 
        filterContent(about, 20), 
        $scope.classRoom.largePicture
      );      
    }

  this.initTagIndex();
  this.loadClassRoom();
};
app.controller('ClassRoomDiscussController', ['$scope', '$stateParams', 'ClassRoomService', 'cordovaUtil', ClassRoomDiscussController]);

function ClassRoomDiscussController($scope, $stateParams, ClassRoomService, cordovaUtil)
{
	$scope.threads = [];
	$scope.initThreads = function() {
		ClassRoomService.getThreads({
			simplify : 1,
			sort : "posted",
			limit : 10,
			classRoomId : $stateParams.classRoomId
		}, function(data) {
			$scope.threads = data.resources;
		});
	}

	$scope.showThread = function(thread) {
		cordovaUtil.startAppView("threadDiscuss", {
	        type : "thread.post",
	        targetId : thread.targetId,
	        targetType : 'classroom',
	        threadId : thread.id,
	        threadType : thread.type
	    });
	};

	cordovaUtil.addEvent("createThreadEvent", $scope.initThreads);
};
app.controller(
  'ClassRoomListController', 
  [
    '$scope', 
    '$stateParams', 
    '$state',
    'cordovaUtil', 
    'CourseUtil', 
    'ClassRoomService', 
    'CategoryService', 
    'ClassRoomUtil',
    '$location',
     ClassRoomListController
  ]
);

function ClassRoomListController($scope, $stateParams, $state, cordovaUtil, CourseUtil, ClassRoomService, CategoryService, ClassRoomUtil, $location)
{
    var self = this;
    $scope.categoryTab = {
      category : "分类",
      type : "全部分类",
      sort : "综合排序",
    };

    var query = $location.$$search;

    this.getSortName = function(q) {
      if (!q.orderType) {
        return "综合排序";
      }

      switch(q.orderType) {
        case "hot":
          return "最热";
        case "recommend":
          return "推荐";
        case "new":
          return "最新";
      }
    };

    this.getSortType = function(q) {
      if (!q.orderType) {
        return "createdTime";
      }

      switch(q.orderType) {
        case "hot":
          return "studentNum";
        case "recommend":
          return "recommendedSeq";
        case "new":
          return "createdTime";
      }
    };

    this.findNameInArrayById = function(categoryId, array) {
      for (var i = 0; i < array.length; i++) {
        if (categoryId == array[i].id) {
          return array[i].name;
        }
        if (array[i].childs) {
          var name = self.findNameInArrayById(categoryId, array[i].childs);
          if (name != "") {
            return name;
          }
        }
      };

      return "";
    };

    this.initCategoryName = function(categoryId, categoryTree) {
      if (!categoryId) {
        return;
      }
      var name = self.findNameInArrayById(categoryId, categoryTree.data);

      if (name != "") {
        $scope.categoryTab.category = name;
      }
    };

    $scope.categoryTab = {
      category : "分类",
      type : "全部分类",
      sort : this.getSortName(query),
    };

    $scope.canLoad = true;
    $scope.start = $scope.start || 0;
    $stateParams.categoryId = query.categoryId;
    $scope.sort = this.getSortType(query);

    $scope.loadMore = function(successCallback){
          if (! $scope.canLoad) {
            if (successCallback) {
            successCallback();
             }
            return;
          }
         setTimeout(function() {
            $scope.loadClassRoomList($stateParams.sort, successCallback);
         }, 200);
       
    };

    $scope.loadClassRoomList = function(sort, successCallback) {
           $scope.showLoad();
            ClassRoomService.searchClassRoom({
              limit : 10,
              start: $scope.start,
              category : $stateParams.categoryId,
              sort : sort,
              type : $stateParams.type
            }, function(data) {
              $scope.hideLoad();
              if (successCallback) {
                successCallback();
              }

              var length  = data ? data.data.length : 0;
              if (!data || length == 0 || length < 10) {
                  $scope.canLoad = false;
              }

              $scope.classRooms = $scope.classRooms || [];
              for (var i = 0; i < length; i++) {
                $scope.classRooms.push(ClassRoomUtil.filterClassRoom(data.data[i]));
              };

              $scope.start += 10;
            });
    }

    $scope.courseListSorts = CourseUtil.getClassRoomListSorts();

    CategoryService.getCategorieTree({
      groupCode : "classroom"
    }, function(data) {
      $scope.categoryTree = data;
      self.initCategoryName(query.categoryId, data);
    });

    $scope.selectType = function(item) {
           $scope.$emit("closeTab", {});
           $scope.categoryTab.type = item.name;
           clearData();
           $stateParams.type  = item.type;
           setTimeout(function(){
              $scope.loadClassRoomList($scope.sort);
           }, 100);
    };

    function clearData() {
      $scope.canLoad = true;
      $scope.start = 0;
      $scope.classRooms = null;
    }

    $scope.selectSort = function(item) {
      $scope.$emit("closeTab", {});
      $scope.categoryTab.sort = item.name;
      $scope.sort = item.type;
      clearData();
      setTimeout(function(){
          $scope.loadClassRoomList(item.type);
       }, 100);
    }

    $scope.onRefresh = function() {
      clearData();
      $scope.loadClassRoomList($scope.sort);
    }

    $scope.gotoNativeDetailClassroomPage = function (classroomId) {
      cordovaUtil.openNativeClassroomDetailPage(classroomId);
    };

    $scope.categorySelectedListener = function(category) {
           $scope.$emit("closeTab", {});
           $scope.categoryTab.category = category.name;
           clearData();
           $stateParams.type = null;
           $stateParams.categoryId  =category.id;
           $scope.loadClassRoomList($scope.sort);
    }

    $scope.loadClassRoomList();
};
app.controller('CourseController', ['$scope', '$stateParams', 'CourseService', 'AppUtil', '$state', 'cordovaUtil', CourseController]);
app.controller('CourseSettingController', ['$scope', '$stateParams', 'CourseService', 'ClassRoomService', CourseSettingController]);

function CourseSettingController($scope, $stateParams, CourseService, $window)
{
  $scope.isLearn = $stateParams.isLearn;
  $scope.exitLearnCourse = function(reason) {
    $scope.showLoad();
    CourseService.unLearnCourse({
      reason : reason,
      courseId : $stateParams.courseId
    }, function(data) {
      $scope.hideLoad();
      if (! data.error) {
        $window.history.back();
        setTimeout(function() {
          $scope.$emit("refresh", {});
        }, 10);
        
      } else {
        $scope.toast(data.error.message);
      }
    });
  }
}

app.controller('CourseToolController', ['$scope', '$stateParams', 'OrderService', 'CourseService', 'UserService', 'cordovaUtil', '$state', CourseToolController]);

function BaseToolController($scope, OrderService, UserService, cordovaUtil)
{
  var self = this;

  this.payCourse = function(price, targetType, targetId) {
      OrderService.createOrder({
        payment : "alipay",
        payPassword : "",
        totalPrice : price,
        couponCode : "",
        targetType : targetType,
        targetId : targetId
      }, function(data) {
        if (data.paid == true) {
          console.log("reload");
          window.location.reload();
        } else {
          var error = "加入学习失败";
          if (data.error) {
            error = data.error.message;
          }
          $scope.toast(error);
        }
      }, function(error) {
        console.log(error);
      });
  }

  this.canVipLeand = function(vipLevelId) {
    if($scope.vipLevels.length <= 0 || vipLevelId <= 0){
      return false;
    }
    
    return true;
  }

  this.vipLeand = function(vipLevelId, callback) {
    if ($scope.user == null) {
      esNativeCore.originalLogin();
      return;
    }
    
    $scope.showLoad();
    UserService.getUserInfo({
      userId : $scope.user.id,
    }, function(data) {
      $scope.hideLoad();
      if (data.vip == null || data.vip.levelId < vipLevelId) {
        cordovaUtil.openWebView(app.rootPath + "#/viplist");
      } else {
        callback();
      }
    });
  }

  this.join = function(callback) {
      if ($scope.user == null) {
        esNativeCore.originalLogin();
        return;
      }
      
      callback();
  }

  $scope.getJoinBtnCls = function(targetStatus) {
    var cls = "";
    var isCanShowConsultBtn = $scope.isCanShowConsultBtn();
    cls += isCanShowConsultBtn ? "btn-col-45" : "btn-col-75";
    cls += "closed" != targetStatus ? " btn-yellow" : " btn-gray";

    return cls;
  };

  $scope.isCanShowConsultBtn = function() {
      if ($scope.course && "classroom" == $scope.course.source) {
        return false;
      }

      if (!$scope.teachers || $scope.teachers.length == 0) {
        return false;
      }

      return true;
  };

  $scope.consultCourseTeacher = function() {
    if ($scope.user == null) {
      esNativeCore.originalLogin();
      return;
    }
    if (!$scope.teachers || $scope.teachers.length == 0) {
      alert("该课程暂无教师");
      return;
    }

    var userId = $scope.teachers[0].id;
    cordovaUtil.startAppView("courseConsult", { userId : userId });
  };

  $scope.postQuestion = function(targetType, targetId, type) {
      var threadType = "course";
      if (targetType == "classroom") {
        threadType = "common";
      }
      cordovaUtil.startAppView("threadCreate", {
        targetId : targetId,
        targetType : targetType,
        threadType : threadType,
        type : type ? type : "question"
      });
  };

  $scope.continueLearnCourse = function() {
      $scope.$root.$emit("continueLearnCourse", {});
  };

  $scope.$root.$on("initLearnBtnStatus", function(event, data) {
    $scope.lastIndex = data.lastIndex;
  });

  $scope.$root.$on("tabClick", function(event, data) {
    $scope.currentPage = data.index;
    $scope.$apply();
  });
}

function CourseToolController($scope, $stateParams, OrderService, CourseService, UserService, cordovaUtil, $state)
{
    this.__proto__ = new BaseToolController($scope, OrderService, UserService, cordovaUtil);
    var self = this;
    $scope.userVipLevel = 0;
    if ($scope.user) {
      UserService.getUserInfo({
        userId: $scope.user.id,
      }, function (data) {
        if (data.vip != null) {
          $scope.userVipLevel = data.vip.levelId;
        }
      });
    }
    this.goToPay = function() {
      var course = $scope.course;
      var price = course.price;
        console.log("---" + $scope.course.vipLevelId);
      if (price <= 0) {
        self.payCourse(price, "course", $stateParams.courseId);
      } else {
        $state.go("coursePay", { targetId : $scope.course.id, targetType : 'course' });
      }
    };

    this.checkModifyUserInfo = function(modifyInfos) {
      for (var i = 0; i < modifyInfos.length; i++) {
        var modifyInfo = modifyInfos[i];
        if (!modifyInfo["content"] || modifyInfo["content"] == 0) {
          alert("请填写" + modifyInfo["title"]);
          return false;
        }
      };

      return true;
    }

    $scope.$parent.updateModifyInfo = function() {
      var modifyInfos = $scope.$parent.modifyInfos;
      if (!self.checkModifyUserInfo(modifyInfos)) {
        return;
      }
      $scope.showLoad()
      CourseService.updateModifyInfo({
        targetId : $scope.course.id
      }, function(data) {
        $scope.hideLoad();
        if (data.error) {
          $scope.toast(data.error.message);
          return;
        }
        if (true == data) {
          self.goToPay();
        }
      });
    };

    this.getModifyUserInfo = function(success) {
      $scope.$parent.close = function() {
        self.dialog.dialog("hide");
      }

      CourseService.getModifyInfo({}, function(data) {

        if(true != data["buy_fill_userinfo"]) {
          success();
          return
        }

        $scope.$parent.modifyInfos = data["modifyInfos"];
        if (data["modifyInfos"].length > 0) {
          self.dialog = $(".ui-dialog");
          self.dialog.dialog("show");
        } else {
          success();
        }
      });
    };

    this.vipLeandCourse = function() {
      self.vipLeand($scope.course.vipLevelId, function() {
        CourseService.vipLearn({
          courseId : $stateParams.courseId
        }, function(data){
          alert(1);
          if (! data.error) {
            window.location.reload();
          } else {
            $scope.toast(data.error.message);
          }
        }, function(error) {
          console.log(error);
        });
      });
    }

    $scope.joinCourse = function() {
      if ($scope.course.status == 'closed') {
        alert("课程已关闭!");
        return;
      }

      if ($scope.course.buyable != 1 && $scope.course.status == 'published') {
        alert("该课程限制加入，请联系管理员");
        return;
      }

      if ($scope.course.buyable != 1 && $scope.course.status != 'published') {
        alert("该课程限制加入，请联系管理员");
        return;
      }

      if ($scope.course.buyable != 1 && $scope.course.vipLevelId > 0 && $scope.userVipLevel < $scope.course.vipLevelId) {
        alert("该课程为会员课程，成为会员免费学习");
        return;
      }

      self.join(function() {
        self.goToPay();
      });

    }
}

function CourseController($scope, $stateParams, CourseService, AppUtil, $state, cordovaUtil)
{
    $scope.showLoad();

    CourseService.getCourse({
      courseId : $stateParams.courseId
    }, function(data) {
      if (data && data.error) {
        var dia = $.dialog({
                title : '课程预览' ,
                content : data.error.message,
                button : [ "确认" ]
        });

        dia.on("dialog:action",function(e){
                cordovaUtil.closeWebView();
        });
        return;
      }
      $scope.ratingArray = AppUtil.createArray(5);
      $scope.vipLevels = data.vipLevels;
      $scope.course = data.course;
      $scope.member = data.member;
      $scope.isFavorited = data.userFavorited;
      $scope.discount = data.discount;
      $scope.teachers = data.course.teachers;

      if (data.member) {
        var progress = data.course.lessonNum == 0 ? 0 : data.member.learnedNum / data.course.lessonNum;
        $scope.learnProgress = ((progress * 100).toFixed(2)) + "%" ;
      }

      $scope.courseView = app.viewFloder + (data.member ? "view/course_learn.html" : "view/course_no_learn.html");
      $scope.hideLoad();
    });

    $scope.loadReviews = function(){
      CourseService.getReviews({
        courseId : $stateParams.courseId,
        limit : 1
      }, function(data) {
        $scope.reviewCount = data.total;
        $scope.reviews = data.data;
      });
    }

    $scope.exitLearnCourse = function(reason) {
      $scope.showLoad();
      CourseService.unLearnCourse({
        reason : reason,
        courseId : $stateParams.courseId
      }, function(data) {
        $scope.hideLoad();
        if (! data.error) {
          window.location.reload();
        } else {
          $scope.toast(data.error.message);
        }
      });
    }

    $scope.showDownLesson = function() {
      cordovaUtil.showDownLesson($scope.course.id);
    }

    $scope.showCourseSetting = function () {
      cordovaUtil.showCourseSetting($scope.course.id,"course");
    }

    $scope.$parent.$on("refresh", function(event, data) {
      window.location.reload();
    });

    $scope.showStudents = function() {
      cordovaUtil.openWebView(app.rootPath + "#/studentlist/course/" + $stateParams.courseId);
    };

    $scope.favoriteCourse = function() {

      if ($scope.user == null) {
        esNativeCore.originalLogin();
        return;
      }

      var params = {
          courseId : $stateParams.courseId
      };

      if ($scope.isFavorited) {
        CourseService.unFavoriteCourse(params, function(data) {
          if (data == true) {
            $scope.isFavorited = false;
          }
        });
      } else {
        CourseService.favoriteCourse(params, function(data) {
          if (data == true) {
            $scope.isFavorited = true;
          }
        });
      }
    };

    $scope.shardCourse = function() {
      function filterContent(content, limit) {

          content = content.replace(/<\/?[^>]*>/g,'');
          content = content.replace(/[\r\n\s]+/g,'');
          if (content.length > limit) {
               content = content.substring(0, limit);
            }
            
            return content;
        }

      var about = $scope.course.about;

      cordovaUtil.share(
        app.host + "/course/" + $scope.course.id, 
        $scope.course.title, 
        filterContent(about, 20), 
        $scope.course.largePicture
      );      
    }
}

app.controller('ClassRoomController', ['$scope', '$stateParams', 'ClassRoomService', 'AppUtil', '$state', 'cordovaUtil', 'ClassRoomUtil', ClassRoomController]);
app.controller('ClassRoomToolController', ['$scope', '$stateParams', 'OrderService', 'ClassRoomService', 'UserService', 'cordovaUtil', '$state', ClassRoomToolController]);

function ClassRoomToolController($scope, $stateParams, OrderService, ClassRoomService, UserService, cordovaUtil, $state)
{
  this.__proto__ = new BaseToolController($scope, OrderService, UserService, cordovaUtil);
    var self = this;
    $scope.userVipLevel = 0;
    if ($scope.user) {
      UserService.getUserInfo({
        userId: $scope.user.id,
      }, function (data) {
        if (data.vip != null) {
          $scope.userVipLevel = data.vip.levelId;
        }
      });
    }
    $scope.signDate = new Date();
    this.goToPay = function() {
      var classRoom = $scope.classRoom;
      var price = classRoom.price;
      if (price <= 0) {
        self.payCourse(price, "classroom", $stateParams.classRoomId);
      } else {
        $state.go("coursePay", { targetId : $scope.classRoom.id, targetType : 'classroom' });
      }
    };

    $scope.sign = function() {
      if ($scope.signInfo && $scope.signInfo.isSignedToday) {
        $scope.toast("今天已经签到了!");
        return;
      }
      ClassRoomService.sign({
        classRoomId : $stateParams.classRoomId
      }, function(data) {
        if(data.error) {
          $scope.toast(data.error.message);
          return;
        }

        $scope.signInfo = data;
      });
    }

    $scope.joinClassroom = function() {
      if ($scope.classRoom.status == 'closed') {
        alert("班级已关闭!");
        return;
      }

      if ($scope.classRoom.buyable != 1 && $scope.classRoom.status == 'published') {
        alert("该班级限制加入，请联系管理员");
        return;
      }

      if ($scope.classRoom.buyable != 1 && $scope.classRoom.status != 'published') {
        alert("该班级限制加入，请联系管理员");
        return;
      }

      if ($scope.classRoom.buyable != 1 && $scope.classRoom.vipLevelId > 0 && $scope.userVipLevel < $scope.classRoom.vipLevelId) {
        alert("该课程为会员课程，成为会员免费学习");
        return;
      }
      
      self.join(function() {
        self.goToPay();
      });
    }

    $scope.getTodaySignInfo = function() {
      ClassRoomService.getTodaySignInfo({
        classRoomId : $stateParams.classRoomId
      }, function(data) {
        $scope.signInfo = data;
      });
    };


    $scope.learnByVip = function() {
      self.vipLeand($scope.classRoom.vipLevelId, function() {
        ClassRoomService.learnByVip({
          classRoomId : $stateParams.classRoomId
        }, function(data){
          if (! data.error) {
            window.location.reload();
          } else {
            $scope.toast(data.error.message);
          }
        }, function(error) {
          console.log(error);
        });
      });
    }
}

function ClassRoomController($scope, $stateParams, ClassRoomService, AppUtil, $state, cordovaUtil, ClassRoomUtil)
{
  var self = this;

  this.loadClassRoom = function() {
    $scope.showLoad();
    ClassRoomService.getClassRoom({
      id : $stateParams.classRoomId
    }, function(data) {
      $scope.ratingArray = AppUtil.createArray(5);
      $scope.vipLevels = data.vipLevels;
      $scope.member = data.member;
      $scope.isFavorited = data.userFavorited;
      $scope.discount = data.discount;

      $scope.classRoomView = app.viewFloder + (data.member ? "view/classroom_learn.html" : "view/classroom_no_learn.html");
      $scope.classRoom = ClassRoomUtil.filterClassRoom(data.classRoom);
      $scope.hideLoad();
    });
  };

  $scope.loadClassRoomDetail = function() {
    $scope.classRoomDetailContent = $scope.classRoom.about;
  }

  $scope.loadReviews = function(){
      ClassRoomService.getReviews({
        classRoomId : $stateParams.classRoomId,
        limit : 1
      }, function(data) {
        $scope.reviews = data.data;
      });
  };

  $scope.loadStudents = function() {
    ClassRoomService.getStudents({
      classRoomId : $stateParams.classRoomId,
      limit : 3
    }, function(data) {
      $scope.students = data.resources;
    });
  };

  $scope.loadTeachers = function() {
    ClassRoomService.getTeachers({
      classRoomId : $stateParams.classRoomId,
    }, function(data) {
      if (data && data.length > 1) {
        var length = data.length;
        for (var i = 2; i < length; i++) {
          data.pop();
        };
      }

      $scope.teachers = data;
    });
  };

  $scope.unLearn = function(reason) {
      $scope.showLoad();
      ClassRoomService.unLearn({
        reason : reason,
        targetType : "classroom",
        classRoomId : $stateParams.classRoomId
      }, function(data) {
        $scope.hideLoad();
        if (! data.error) {
          window.location.reload();
        } else {
          $scope.toast(data.error.message);
        }
      });
    }

    $scope.showStudents = function() {
      cordovaUtil.openWebView(app.rootPath + "#/studentlist/classroom/" + $stateParams.classRoomId);
    };

    $scope.showCourseSetting = function() {
      cordovaUtil.showCourseSetting($stateParams.classRoomId,"classroom");
    };

    $scope.shardCourse = function() {
      function filterContent(content, limit) {

          content = content.replace(/<\/?[^>]*>/g,'');
          content = content.replace(/[\r\n\s]+/g,'');
          if (content.length > limit) {
               content = content.substring(0, limit);
            }
            
            return content;
        }

      var about = $scope.classRoom.about;

      cordovaUtil.share(
        app.host + "/classroom/" + $scope.classRoom.id, 
        $scope.classRoom.title, 
        filterContent(about, 20), 
        $scope.classRoom.largePicture
      );      
    }

  this.loadClassRoom();
}

app.controller('CourseCardController', ['$scope', '$stateParams', 'CourseService','cordovaUtil', CourseCardController]);
function CourseCardController($scope, $stateParams, CourseService,cordovaUtil)
{

  CourseService.getCourse({
    courseId : $stateParams.courseId
  }, function(data) {
    $scope.course = data.course;
    $scope.$parent.title = data.course.title;
  });

  $scope.gotoNativeDetailCoursePage = function (courseId) {
          cordovaUtil.openNativeCourseDetailPage(courseId,"courseSet");

    };




};
app.controller('CourseDetailController', ['$scope', '$stateParams', 'CourseService', 'SettingService', CourseDetailController]);

function CourseDetailController($scope, $stateParams, CourseService, SettingService)
{
  CourseService.getCourse({
      courseId : $stateParams.courseId
    }, function(data) {
      $scope.course = data.course;
  });

  SettingService.getCourseSettings({}, function(data) {
       $scope.shouldShowStudentNum = data.show_student_num_enabled;   
  });

  $scope.getVipTitle = function(vipLevelId) {
      var vipLevels = $scope.vipLevels;
      for (var i = 0; i < vipLevels.length; i++) {
        var level = vipLevels[i];
        if (level.id == vipLevelId) {
          return level.name;
        }
      };
      
      return "";
  }

  $scope.isCanShowVip = function(vipLevelId) {
  	if ($scope.member) {
      return false;
    }

    if($scope.vipLevels.length <= 0 || vipLevelId <= 0){
   	  return false;
    }
    return true;
  }
}
;
app.controller('CourseDiscussController', ['$scope', '$stateParams', 'CourseService', 'cordovaUtil', CourseDiscussController]);

function CourseDiscussController($scope, $stateParams, CourseService, cordovaUtil)
{
	$scope.threads = [];
	$scope.initThreads = function() {
		CourseService.getThreads({
			simplify : 1,
			sort : "posted",
			limit : 100,
			courseId : $stateParams.courseId
		}, function(data) {
			$scope.threads = data.resources;
		});
	}

	$scope.showThread = function(thread) {
		cordovaUtil.startAppView("threadDiscuss", {
	        type : "thread.post",
	        targetId : thread.courseId,
	        targetType : 'course',
	        threadId : thread.id,
	        threadType : thread.type
	    });
	};

	cordovaUtil.addEvent("createThreadEvent", $scope.initThreads);
}

app.controller('ClassRoomDiscussController', ['$scope', '$stateParams', 'ClassRoomService', 'cordovaUtil', ClassRoomDiscussController]);

function ClassRoomDiscussController($scope, $stateParams, ClassRoomService, cordovaUtil)
{
	$scope.threads = [];
	$scope.initThreads = function() {
		ClassRoomService.getThreads({
			simplify : 1,
			sort : "posted",
			limit : 100,
			classRoomId : $stateParams.classRoomId
		}, function(data) {
			$scope.threads = data.resources;
		});
	}

	$scope.showThread = function(thread) {
		cordovaUtil.startAppView("threadDiscuss", {
	        type : "thread.post",
	        targetId : thread.targetId,
	        targetType : 'classroom',
	        threadId : thread.id,
	        threadType : thread.type
	    });
	};

	cordovaUtil.addEvent("createThreadEvent", $scope.initThreads);
};
app.controller('CourseListController', ['$scope', '$stateParams', '$state', 'cordovaUtil', 'CourseUtil', 'CourseService', 'CategoryService', CourseListController]);
function CourseListController($scope, $stateParams, $state, cordovaUtil, CourseUtil, CourseService, CategoryService, $location)
{
    var self = this;
    var query = $location.$$search;
    this.getTypeName = function(name, types) {

      var defaultName = "全部分类";
      if (!name || !types) {
        return defaultName;
      }

      for (var i = types.length - 1; i >= 0; i--) {
        if (name == types[i].type) {
          defaultName = types[i].name;
          break;
        }
      };

      return defaultName;
    }

    this.getSortName = function(q) {
      if (!q.orderType) {
        return "综合排序";
      }

      switch(q.orderType) {
        case "hot":
          return "最热";
        case "recommend":
          return "推荐";
        case "new":
          return "最新";
      }
    };

    this.getSortType = function(q) {
      if (!q.orderType) {
        return "createdTime";
      }

      switch(q.orderType) {
        case "hot":
          return "-studentNum";
        case "recommend":
          return "recommendedSeq";
        case "new":
          return "-createdTime";
      }
    };
    $scope.gotoNativeDetailCoursePage = function (courseId) {
      cordovaUtil.openNativeCourseDetailPage(courseId, "courseSet");
    };

    $scope.courseListSorts = CourseUtil.getCourseListSorts();
    $scope.courseListTypes = CourseUtil.getCourseListTypes();
    $scope.categoryTab = {
      category : "分类",
      type : this.getTypeName($stateParams.type, $scope.courseListTypes),
      sort : this.getSortName(query),
    };

    $scope.canLoad = true;
    $stateParams.categoryId = query.categoryId;
    $scope.sort = this.getSortType(query);
    $scope.shouldShowStudentNum = query.shouldShowStudentNum;
    $scope.start = $scope.start || 0;

    $scope.loadMore = function(successCallback){
      if (! $scope.canLoad) {
          if (successCallback) {
            successCallback();
          }
          return;
      }
      setTimeout(function() {
          $scope.loadCourseList($scope.sort, successCallback);
      }, 200);
    };

    $scope.loadCourseList = function(sort, successCallback) {
           $scope.showLoad();
            CourseService.searchCourse({
              limit : 10,
              offset: $scope.start,
              categoryId : $stateParams.categoryId,
              sort : sort,
              type : $stateParams.type
            }, function(data) {
                      $scope.hideLoad();
                      if (successCallback) {
                        successCallback();
                      }
                      var length  = data ? data.data.length : 0;
                      if (!data || length == 0 || length < 10) {
                          $scope.canLoad = false;
                      }

                      $scope.courses = $scope.courses || [];
                      for (var i = 0; i < length; i++) {
                        $scope.courses.push(data.data[i]);
                      };

                      $scope.start += 10;
            });
    }

    this.findNameInArrayById = function(categoryId, array) {
      for (var i = 0; i < array.length; i++) {
        if (categoryId == array[i].id) {
          return array[i].name;
        }
        if (array[i].children) {
          var name = self.findNameInArrayById(categoryId, array[i].children);
          if (name != "") {
            return name;
          }
        }
      };

      return "";
    };

    this.initCategoryName = function(categoryId, categoryTree) {
      if (!categoryId) {
        return;
      }
      var name = self.findNameInArrayById(categoryId, categoryTree);

      if (name != "") {
        $scope.categoryTab.category = name;
      }
    };

    CategoryService.getCategorieTree({
        groupCode : "course"
    },function(data) {
      $scope.categoryTree = data;
      self.initCategoryName(query.categoryId, data);
    });

    $scope.selectType = function(item,successCallback) {
           $scope.$emit("closeTab", {});
           $scope.categoryTab.type = item.name;
           clearData();
           $stateParams.type  = item.type;
           setTimeout(function(){
              $scope.loadCourseList($scope.sort,successCallback);
           }, 100);
    }

    function clearData() {
              $scope.canLoad = true;
              $scope.start = 0;
              $scope.courses = null;
    }

    $scope.selectSort = function(item,successCallback) {
      $scope.$emit("closeTab", {});
      $scope.categoryTab.sort = item.name;
      $scope.sort = item.type;
      clearData();
      setTimeout(function(){
          $scope.loadCourseList(item.type,successCallback);
       }, 100);
    }

    $scope.onRefresh = function() {
      clearData();
      $scope.loadCourseList($scope.sort,successCallback);
    }

    $scope.categorySelectedListener = function(category,successCallback) {
           $scope.$emit("closeTab", {});
           $scope.categoryTab.category = category.name;
           clearData();
           $stateParams.categoryId  = category.id;
           $scope.loadCourseList($scope.sort,successCallback);
    }
    $scope.getDiscountPrice = function(course) {
      return course.minCoursePrice / course.discount * 10;
    } 

    $scope.loadCourseList($scope.sort);
};
app.controller('CourseNoticeController', ['$scope', 'CourseService', 'ClassRoomService', '$stateParams', CourseNoticeController]);

function CourseNoticeController($scope, CourseService, ClassRoomService, $stateParams)
{
	var limit = 10;
	$scope.start = 0;
	$scope.showLoadMore = false;
	
	this.loadCourseNotices = function(callback) {
	    CourseService.getCourseNotices({
	      start : $scope.start,
	      limit : limit,
	      courseId : $stateParams.targetId
	    }, callback);
	};

  	this.loadClassRoomNotices = function(callback) {
	    ClassRoomService.getAnnouncements({
	      start : $scope.start,
	      limit : 10,
	      classRoomId : $stateParams.targetId
	    }, callback);
	};

  	this.initTargetService = function(targetType) {
	    if (targetType == "course") {
	    	$scope.titleType = "课程";
	      	self.targetService = this.loadCourseNotices;
	    } else if (targetType == "classroom") {
	    	$scope.titleType = "班级";
	      	self.targetService = this.loadClassRoomNotices;
	    }
	};


	function loadNotices(start, limit) {
		$scope.showLoad();
		self.targetService(function(data) {
			$scope.hideLoad();
			$scope.notices = $scope.notices || [];
			if (!data || data.length == 0) {
				$scope.showLoadMore = false;
				return;
			}

			$scope.showLoadMore = true;
			for (var i = 0; i < data.length; i++) {
                $scope.notices.push(data[i]);
           	};
			$scope.start += limit;
		});
	}

	$scope.loadMore = function() {
		loadNotices($scope.start, limit);
	}

	this.initTargetService($stateParams.targetType);
};
app.controller('CourseReviewController', ['$scope', '$stateParams', 'CourseService', 'ClassRoomService', CourseReviewController]);

function CourseReviewController($scope, $stateParams, CourseService, ClassRoomService)
{
  var self = this;
  this.targetId = 0;
  $scope.canLoad = true;
  $scope.start = $scope.start || 0;

  $scope.loadMore = function(){
        if (! $scope.canLoad) {
          return;
        }
       setTimeout(function() {
          self.loadReviews();
       }, 200);
  };

  this.loadCourseReviews = function(callback) {
    CourseService.getReviews({
      start : $scope.start,
      limit : 50,
      courseId : self.targetId
    }, callback);
  };

  this.loadClassRoomReviews = function(callback) {
    ClassRoomService.getReviews({
      start : $scope.start,
      limit : 50,
      classRoomId : self.targetId
    }, callback);
  };

  this.initTargetService = function(targetType) {
    if (targetType == "course") {
      self.targetInfoService = self.loadCourseReviewInfo;
      self.targetService = self.loadCourseReviews;
    } else if (targetType == "classroom") {
      self.targetInfoService = self.loadClassRoomReviewInfo;
      self.targetService = self.loadClassRoomReviews;
    }
  };

  this.loadReviews = function() {
    self.targetService(function(data) {
      var length  = data ? data.data.length : 0;
      if (!data || length == 0 || length < 50) {
          $scope.canLoad = false;
      }

      $scope.reviews = $scope.reviews || [];
      for (var i = 0; i < length; i++) {
        $scope.reviews.push(data.data[i]);
      };

      $scope.start += data.limit;
    });
  };

  this.loadCourseReviewInfo = function() {
    CourseService.getCourseReviewInfo({
      courseId : self.targetId
    }, function(data) {
      data.info.rating = Math.round(data.info.rating * 10) / 10;
      data.progress = data.progress.reverse();
      $scope.reviewData = data;
    });
  }

  this.loadClassRoomReviewInfo = function() {
    ClassRoomService.getReviewInfo({
      classRoomId : self.targetId
    }, function(data) {
      data.info.rating = Math.round(data.info.rating * 10) / 10;
      data.progress = data.progress.reverse();
      $scope.reviewData = data;
    });
  }

  $scope.loadReviewResult = function(targetType, targetId) {
    self.targetId = targetId;
    self.targetType = targetType;
    self.initTargetService(self.targetType);
    self.targetInfoService();
    self.loadReviews();
  }
};
app.controller('CourseSettingController', ['$scope', '$stateParams', 'CourseService', 'ClassRoomService', CourseSettingController]);

function CourseSettingController($scope, $stateParams, CourseService, $window)
{
  $scope.isLearn = $stateParams.isLearn;
  $scope.exitLearnCourse = function(reason) {
    $scope.showLoad();
    CourseService.unLearnCourse({
      reason : reason,
      courseId : $stateParams.courseId
    }, function(data) {
      $scope.hideLoad();
      if (! data.error) {
        $window.history.back();
        setTimeout(function() {
          $scope.$emit("refresh", {});
        }, 10);
        
      } else {
        $scope.toast(data.error.message);
      }
    });
  }
};
app.controller('FoundCourseController', ['$scope', 'SchoolService', '$state', FoundCourseController]);

function FoundCourseController($scope, SchoolService, $state)
{
	SchoolService.getSchoolBanner(function(data) {
		$scope.banners = data;
	});

	SchoolService.getRecommendCourses({ limit : 3 }, function(data) {
		$scope.recommedCourses = data.data;
	});

	SchoolService.getLatestCourses({ limit : 3 }, function(data) {
		$scope.latestCourses = data.data;
	});
}

app.controller('FoundLiveController', ['$scope', 'SchoolService', FoundLiveController]);

function FoundLiveController($scope, SchoolService)
{
	SchoolService.getLiveRecommendCourses({ limit : 3 } , function(data) {
		$scope.liveRecommedCourses = data.data;
	});

	SchoolService.getLiveLatestCourses( {  limit : 3,  },  function(data) {
		$scope.liveLatestCourses = data.data;
	});
}

app.controller('FoundClassRoomController', ['$scope', 'ClassRoomService', 'ClassRoomUtil', FoundClassRoomController]);

function FoundClassRoomController($scope, ClassRoomService, ClassRoomUtil)
{
  	ClassRoomService.getRecommendClassRooms({ limit : 3 }, function(data) {
  		$scope.recommendClassRooms = ClassRoomUtil.filterClassRooms(data.data);
  	});

  	ClassRoomService.getLatestClassrooms({ limit : 3 }, function(data) {
  		$scope.latestClassrooms = ClassRoomUtil.filterClassRooms(data.data);
  	});


};
app.controller('HomeWorkController', ['$scope', '$stateParams', 'HomeworkManagerService', 'AppUtil', HomeworkCheckController]);

function HomeworkCheckController($scope, $stateParams, HomeworkManagerService, AppUtil)
{
	function uncertainChoiceType(item) {
		return new choiceType(item);

	}

	function choiceType(item) {
		var self = this;

		this.getResultAnswer = function() {
			if (item.result && item.result.length > 0) {
				var answer = item.result.answer;
				return self.coverAnswer(answer);
			}

			return "未回答";
		}

		this.getIndexType = function(index) {
			switch (index) {
					case 0:
						return "A";
					case 1:
						return "B";
					case 2:
						return "C";
					case 3:
						return "D";
					case 4:
						return "E";
					case 5:
						return "F";
					case 6:
						return "G";
					case 7:
						return "H";
					case 8:
						return "I";
					case 9:
						return "J";
				}

				return "";
		};

		this.coverAnswer = function(answer) {
			var answerResult = "";
			for (var i = 0; i < answer.length; i++) {
				answerResult += self.getIndexType(i) + ",";
			};

			return answerResult;
		}

		this.getAnswer = function() {
			if (item.answer && item.answer.length > 0) {
				return self.coverAnswer(item.answer);
			}

			return "未回答";	
		};

		return {
			getAnswer : this.getAnswer,
			getIndexType : this.getIndexType,
			getResultAnswer : this.getResultAnswer,
		};
	};

	function essayType(item) {
		var self = this;
		this.getAnswer = function() {
			if (!item.answer || item.answer.length == 0) {
				return "";
			}

			return item.answer[0];	
		};

		this.getResultAnswer = function() {
			if (item.result) {
				var answer = item.result.answer;
				return self.getAnswer(answer);
			}

			return "no";
		}

		return {
			getAnswer : this.getAnswer,
			getResultAnswer : this.getResultAnswer
		};
	};

	var questionType = {
		single_choice : choiceType,
		essay : essayType,
		uncertain_choice : choiceType
	};

	$scope.loadHomeworkResult = function() {
		$scope.showLoad();
		HomeworkManagerService.showCheck({
			homeworkResultId : $stateParams.homeworkResultId
		}, function(data) {
			$scope.hideLoad();
			$scope.homeworkResult = data;
			$scope.items = data.items;
			$scope.currentQuestionIndex = 1;
		});
	};

	$scope.getResultAnswer = function(item) {
		var type = questionType[item.type];
		return type(item).getResultAnswer();
	};

	$scope.getItemAnswer = function(item) {
		var type = questionType[item.type];
		return type(item).getAnswer();
	}

	$scope.getItemStem = function(index, type) {
		var typeStr = "";
		switch (type) {
			case "single_choice":
				typeStr = "单选题";
				break;
			case "determine":
				typeStr = "判断题";
				break;
			case "essay":
				typeStr = "问答题";
				break;
			case "fill":
				typeStr = "填空题";
				break;
			case "material":
				typeStr = "材料题";
				break;
			case "uncertain_choice":
				typeStr = "不定项题";
				break;
			case "choice":
				typeStr = "多选题";
		}

		return AppUtil.formatString("%1, (%2)", index + 1, typeStr);
	}

	$scope.questionItemChange = function() {
		$scope.$apply(function() {
			$scope.currentQuestionIndex = $scope.scrollIndex + 1;
		});
	}

	$scope.getItemView = function(item) {
		var type = item.type;
		if (type.indexOf('choice')!= -1) {
			type = "choice";
		}
		return "view/homework_" + type + "_view.html";
	}

	$scope.getItemIndex = function(item, index) {
		var type = questionType[item.type];
		return type(item).getIndexType(index);
	}

	$scope.getFillQuestionItem = function(item) {
		var items = [], answer = item.answer;
		for (var i = 0; i < answer.length; i++) {
			items[i] = AppUtil.formatString("填写空(%1)答案", i + 1);
		};

		return items;
	}
};
app.controller('SingleLessonController', ['$scope', '$stateParams', '$q', 'LessonService', 'LessonLiveService', 'cordovaUtil', 'platformUtil', SingleLessonController]);

function SingleLessonController($scope, $stateParams, $q, LessonService, LessonLiveService, cordovaUtil, platformUtil)
{ 
  var self = this;
  this.lesson = {};
  this.timeoutNum = 0;
  self.getDevice = function() {
    if (platformUtil.ios || platformUtil.iPhone) {
      return "iphone";
    }

    if (platformUtil.android) {
      return "android";
    }

    return "mobile";
  };

  self.loadLiveReplay = function() {
    showLiveByWebView = function(url) {
      if (! url || "" == url) {
        self.showError({
            message : "获取直播回看服务失败!"
        });
        return;
      }

      $scope.hideLoad();
      cordovaUtil.openWebView(url);
      cordovaUtil.closeWebView();
    }

    LessonLiveService.getLiveReplay({
      id : $stateParams.lessonId,
      device : self.getDevice()
    }, function(data) {
      if (true == data.nonsupport) {
        self.showError({
            message : "直播暂不支持在移动端播放!"
        });
        return;
      }
      if (data.sdk) {
        $scope.hideLoad();
        self.showLiveBySdk(data.sdk, true, data.user, self.lesson);
        return;
      }

      if (data.extra) {
        provider = data.extra.provider;
        cordovaUtil.getSupportLiveClients($q).then(function(clientList) {
          if (clientList.indexOf(provider) != -1) {
            $scope.hideLoad();
            data.extra.url = data.url;
            self.showLiveBySdk(data.extra, true, data.user, self.lesson);
            return;
          }
          showLiveByWebView(data.url);
        });
        return;
      }

      showLiveByWebView(data.url);
    });
  };

  self.loadLiveTicket = function() {
    $scope.showLoad();
    LessonLiveService.createLiveTickets({
      lessonId : $stateParams.lessonId,
      device : self.getDevice()
    }, function(data) {
      if (data.error) {
        $scope.hideLoad();
        self.showError(data.error);
        return;
      }

      if (! data.no) {
        $scope.hideLoad();
        self.showError({
          message : "获取直播服务失败!"
        });
        return;
      }
      self.getLiveInfoFromTicket($stateParams.lessonId, data.no);
    });
  };

  self.showLiveBySdk = function(sdk, isReplay, user, lesson) {
    if (sdk.error) {
      message = sdk.error;
      if (sdk.code == 1408) {
        message = "您已被移出直播教室";
      }
      self.showError({
          message : message
      });
      return;
    }
    switch(sdk.provider) {
      case "soooner":
        cordovaUtil.startAppView("sooonerLivePlayer", {
          liveClassroomId : sdk.liveClassroomId, 
          exStr : sdk.exStr,
          replayState : isReplay
        });
        cordovaUtil.closeWebView();
        break;
      case "gensee":
        cordovaUtil.startAppView("genseeLivePlayer", {
          replayState : isReplay,
          domain : sdk.domain, 
          roomNumber : sdk.roomNumber,
          loginAccount : sdk.loginAccount,
          loginPwd : sdk.loginPwd,
          joinPwd : sdk.joinPwd,
          vodPwd : sdk.vodPwd,
          nickName : sdk.nickName,
          serviceType : sdk.serviceType,
          k : sdk.k
        });
        cordovaUtil.closeWebView();
        break;
      case "longinus":
        if (isReplay) {
          cordovaUtil.startAppView("longinusLivePlayer", {
            playUrl : sdk.url,
            title : lesson.title,
            lessonId : sdk.lessonId,
            replayState : true
          });
          cordovaUtil.closeWebView();
          return;
        }
        playUrl = sdk.play ? sdk.play.url + "/" + sdk.play.stream: "";
        cordovaUtil.startAppView("longinusLivePlayer", {
          replayState : false,
          lessonId : lesson.id,
          title : lesson.title,
          role : sdk.role, 
          token : sdk.token,
          clientId : sdk.clientId,
          clientName : user.nickname,
          roomNo : sdk.roomNo,
          convNo : sdk.convNo,
          playUrl : playUrl,
          liveHost : sdk.requestUrl
        });
        cordovaUtil.closeWebView();
        break;
      case "talkfun":
        cordovaUtil.startAppView("talkfunLivePlayer",{
          token : sdk.access_token,
          id : lesson.id,
          replayState : isReplay
        });
        cordovaUtil.closeWebView();
        break;
      default:
        self.showError({
          message : "暂不支持该直播类型在客户端上播放!"
        });
    }
  }

  self.getLiveInfoFromTicket = function(lessonId, ticket) {

    showLiveByWebView = function(roomUrl) {
      if (! roomUrl || "" == roomUrl) {
        $scope.hideLoad();
        if (self.timeoutNum >= 100) {
          self.showError({
              message : "获取直播服务失败!"
          });
          return;
        }
        self.getLiveInfoFromTicket(lessonId, ticket);
        return;
      }

      $scope.hideLoad();
      cordovaUtil.openWebView(roomUrl);
      cordovaUtil.closeWebView();
    };

    $scope.showLoad();
    LessonLiveService.getLiveInfoByTicket({
      lessonId : lessonId,
      ticket : ticket
    }, function(data) {
      if (data.error) {
        self.showError(data.error);
        return;
      }
      self.timeoutNum ++;

      if (data.sdk) {
        $scope.hideLoad();
        self.showLiveBySdk(data.sdk, false, data.user, self.lesson);
        return;
      }

      if (data.extra) {
        provider = data.extra.provider;
        cordovaUtil.getSupportLiveClients($q).then(function(clientList) {
          if (clientList.indexOf(provider) != -1) {
            $scope.hideLoad();
            self.showLiveBySdk(data.extra, false, data.user, self.lesson);
            return;
          }
          showLiveByWebView(data.roomUrl);
        });
        return;
      }

      showLiveByWebView(data.roomUrl);
    });
  };

  self.showError = function(error) {
    var dia = $.dialog({
            title : '直播提醒' ,
            content : error.message,
            button : [ "确定" ]
    });

    dia.on("dialog:action",function(e){
      cordovaUtil.closeWebView();
    });
  }

  self.loadLesson = function() {
    $scope.showLoad();
    LessonService.getApiLesson({
      courseId : $stateParams.courseId,
      lessonId : $stateParams.lessonId
    },function(data) {
      $scope.hideLoad();
      if (data.error) {
        $scope.toast(data.error.message);
        return;
      }
      
      self.lesson = data;
      var lesson = data;
      if (!lesson) {
        alert("请先加入学习");
        cordovaUtil.closeWebView();
        return;
      }

      if (lesson.status == "unpublished") {
        alert("课时尚未发布");
        cordovaUtil.closeWebView();
        return;
      }
      if (lesson.type == "flash" || "qqvideo" == lesson.mediaSource) {
        alert("客户端暂不支持该课时类型，敬请期待新版");
        cordovaUtil.closeWebView();
        return;
      }

      if ("live" == lesson.type) {
        self.liveProvider = lesson.liveProvider;
        var endTime = lesson.endTime * 1000;
        var currentTime = new Date().getTime();
        if (currentTime > endTime) {
          if (lesson.replayStatus == 'generated') {
            self.loadLiveReplay();
            return;
          }
          if ("videoGenerated" == lesson.replayStatus) {
            cordovaUtil.closeWebView();
            cordovaUtil.learnCourseLesson(lesson.courseId, lesson.id, []);
            return;
          }
          self.showError({
              message : "直播已结束!"
          });

          return;
        }
        self.loadLiveTicket();
        return;
      }

      cordovaUtil.closeWebView();
      cordovaUtil.learnCourseLesson(lesson.courseId, lesson.id, []);
    });
  }

  this.loadLesson();
}

function LessonController($scope, $stateParams, $state, cordovaUtil, platformUtil, LessonService)
{
  var self = this;

  //lesson.free=1 is free
  $scope.learnLesson = function(lesson) {
    if (!$scope.user) {
      var dia = $.dialog({
              title : '课程提醒' ,
              content : '你还未登录网校',
              button : [ "登录网校" ]
      });

      dia.on("dialog:action",function(e){
        esNativeCore.originalLogin();
      });
      return;
    }
    if (lesson.status == "unpublished") {
      alert("课时尚未发布");
      return;
    }

    if (! $scope.member && 1 != lesson.free) {
      alert("请先加入学习");
      return;
    }

    if ("chapter" == lesson.type || lesson.type == "label" || lesson.type == "unit") {
      return;
    }

    if (lesson.type == "flash" || "qqvideo" == lesson.mediaSource) {
      alert("客户端暂不支持该课时类型，敬请期待新版");
      return;
    }

    if ("live" == lesson.type && platformUtil.android) {
      if (!self.checkLiveStartTimeCanEnter(lesson.startTime * 1000)) {
        return;
      }
      $scope.showLoad();
      LessonService.getApiLesson({
                                  lessonId : lesson.id, 
                                  courseId : lesson.courseId
      }, function(data){
        $scope.hideLoad();
        if(data.type == "video"){
          cordovaUtil.learnCourseLesson(lesson.courseId, lesson.id, self.createLessonIds());   
        }else{
          cordovaUtil.openWebView(app.rootPath + "#/lesson/" + lesson.courseId + "/" + lesson.id);
        }
      }, function(error) {
        $scope.hideLoad();
        alert("获取视频信息失败，请重试");
      });
    } else {
      cordovaUtil.learnCourseLesson(lesson.courseId, lesson.id, self.createLessonIds()); 
    }
  };

  this.checkLiveStartTimeCanEnter = function(startTime) {
    nowTime = new Date().getTime();
    if (startTime - nowTime > (30 * 60000)) {
      alert("直播还未开始，稍后再来吧");
      return false;
    }

    return true;
  }

  this.initLearnLessonListener = function() {
    $scope.$root.$$listeners['continueLearnCourse'] = null;
    $scope.$root.$on("continueLearnCourse", function(event, data) {
        if (! $scope.lastLearnStatusIndex) {
          $scope.lastLearnStatusIndex = 0;
        }

        if ($scope.lastLearnStatusIndex == -1) {
          $scope.lastLearnStatusIndex = 0;
        }
        
        var continueLesson = self.findLessonById($scope.lastLearnStatusIndex);

        if (continueLesson == undefined) {
          continueLesson = self.findFirstLesson();
          if (continueLesson == undefined) {
            alert('课程没有可学习的课时');
            return;
          }
        }
        $scope.learnLesson(continueLesson);
      });
  };

  this.createLessonIds = function() {
    var index = 0;
    var lessonIds = [];
    var lessons = $scope.lessons;
    for (var i = 0; i < lessons.length; i++) {
      if (!("unit" == lessons[i].type ||
    "chapter"== lessons[i].type || 
    "label" == lessons[i].type)) {
        lessonIds[index++] = lessons[i].id;
      }
    };

    return lessonIds;
  };

  this.findFirstLesson = function() {
    var lessons = $scope.lessons;
    if (lessons == null || lessons.length == 0) {
      return undefined;
    }
    var index = 0;
    var firstLesson = lessons[index];
    while (firstLesson.type == 'chapter' 
      || firstLesson.type == 'unit'
      || firstLesson.type == 'label') {

      index ++;
      if (index > (lessons.length - 1)) {
        firstLesson = undefined;
        break;
      }
      firstLesson = lessons[index];
    }

    return firstLesson;
  };

  this.findLessonById = function(lessonId) {
    var lessons = $scope.lessons;
    for (var i = 0; i < lessons.length; i++) {
      if (lessonId == lessons[i].id) {
        return lessons[i];
      }
    };

    return undefined;
  };
}

app.controller('CourseLessonController', ['$scope', '$stateParams', 'UserService', 'SettingService', 'LessonService', '$state', 'cordovaUtil', 'platformUtil', CourseLessonController]);
function CourseLessonController($scope, $stateParams, UserService, SettingService, LessonService, $state, cordovaUtil, platformUtil)
{
  this.__proto__ = new LessonController($scope, $stateParams, $state, cordovaUtil, platformUtil, LessonService);
  var self = this;
  $scope.loading = true;
  $scope.errorMsg = null;

  this.checkVipStatus = function(callback) {
    var member = $scope.member;
    if (! member) {
      self.loadLessons();
      return;
    }

    if (member.deadline < 0) {
        $scope.errorMsg = "课程购买已过期，不能学习此课程";
      return;
    }

    if (member.levelId <= 0) {
      self.loadLessons();
      return;
    }

    $scope.showLoad();
    UserService.getUserInfo({
      userId : $scope.user.id
    }, function(data) {
      $scope.hideLoad();
      var vip = data.vip;

      var levelId = $scope.member.levelId;
      if (! vip && levelId > 0) {
        $scope.errorMsg = "您已经不是会员，不能学习此课程";
        return;
      }

      if (levelId > 0 && vip.levelId < levelId) {
        $scope.errorMsg = "会员等级不够，不能学习此课程";
        return;
      }

      var currentTime = new Date().getTime() / 1000;
      var deadline = vip ? vip.deadline : 0;
      if (deadline > 0 && deadline < currentTime) {
        $scope.errorMsg = "您的会员已过期，不能学习此课程";
        return;
      }
      self.loadLessons();
    });
  };

  this.loadLessons = function() {
      $scope.showLoad();
      LessonService.getCourseLessons({
        courseId : $stateParams.courseId,
        token : $scope.token
      }, function(data) {
        $scope.hideLoad();
        $scope.loading = false;
        $scope.lessons = data.lessons;
        $scope.learnStatuses = $scope.member ? data.learnStatuses : [];
        SettingService.getCourseSettings({}, function(data){
          if(data.custom_chapter_enabled != "0"){
            for(var i=0;i < $scope.lessons.length;i++){
              if($scope.lessons[i].type == "chapter"){
                $scope.lessons[i].chapter_name = data.chapter_name;
              }else if($scope.lessons[i].type == "unit"){
                $scope.lessons[i].part_name = data.part_name;
              }
            }
          }
        });

        var isAllLearn = 0;
        for( index in data.learnStatuses ) {
            isAllLearn += data.learnStatuses[index] == "finished" ? 1 : -1;
            $scope.lastLearnStatusIndex = index;
        }

        if (isAllLearn == $scope.lessons.length) {
          $scope.lastLearnStatusIndex = -1;
        }

        $scope.$parent.$emit("initLearnBtnStatus", {
          lastIndex : self.findLessonPosition($scope.lastLearnStatusIndex)
        });
      
        self.initLearnLessonListener();
      });
  }

  this.findLessonPosition = function(lessonId) {
    var lessons = $scope.lessons;
    for (var i = 0; i < lessons.length; i++) {
      if (lessonId == lessons[i].id) {
        return lessons[i].number;
      }
    };

    return -1;
  };

  $scope.getLessonBoxStyle = function($index) {

    var style = "";
    $prevItem = $scope.lessons[$index -1];
    $nextItem = $scope.lessons[$index +1];

    var isNoTop = false, isNoBottom = false;
    if (!$prevItem || 'chapter' == $prevItem.itemType) {
      style += " no-top";
      isNoTop = true;
    }

    if (! $nextItem || 'lesson' != $nextItem.itemType) {
      style += " no-bottom";
      isNoBottom = true;
    }

    if (isNoTop && isNoBottom) {
      style = "hidden";
    }

    return style;
  }

  this.checkVipStatus();
  cordovaUtil.addEvent("lessonStatusRefresh", this.checkVipStatus);
}

app.controller('ClassRoomCoursesController', ['$scope', '$stateParams', 'CourseService', 'ClassRoomService', '$state', 'cordovaUtil', 'platformUtil', ClassRoomCoursesController]);
function ClassRoomCoursesController($scope, $stateParams, CourseService, ClassRoomService, $state, cordovaUtil, platformUtil)
{
  this.__proto__ = new LessonController($scope, $stateParams, $state, cordovaUtil, platformUtil);
  var self = this;

  $scope.loadClassRoomCourses = function() {
    $scope.loading = true;
    ClassRoomService.getClassRoomCourses({
      classRoomId : $stateParams.classRoomId
    }, function(data) {
      $scope.loading = false;
      
      if (data.error) {
        $scope.toast(data.error.message);
        return;
      }
      $scope.courses = data.courses;
      $scope.progressArray = data.progress;
    });
  };

  $scope.loadClassRoomPlayStatus = function() {
    ClassRoomService.getClassRoomPlayStatus({
      classRoomId : $stateParams.classRoomId
    }, function(data) {
      $scope.playStatus = data;
      
      var isAllLearn = false;
      var statuses = new Array();
      for( index in data ) {
        statuses[data[index].lessonId] = data[index].status;
        isAllLearn = data[index].status == "finished";
        $scope.lastLearnStatusIndex = data[index].lessonId;
      }
      $scope.classroomLearnStatuses = statuses;
      if (isAllLearn) {
        $scope.lastLearnStatusIndex = -1;
      }
      $scope.$parent.$emit("initLearnBtnStatus", { 
        lastIndex : $scope.lastLearnStatusIndex 
      });
    });
  };

  $scope.initClassRoomPlay = function() {
    $scope.loading = true;
    ClassRoomService.getClassRoomPlay({
      classRoomId : $stateParams.classRoomId
    }, function(data) {
      $scope.loading = false;
      $scope.lessons = data;
      if ( $scope.user != null) {
        $scope.loadClassRoomPlayStatus();
      }
      self.initLearnLessonListener();
    });
  };

  this.findPlayStatusByLessonId = function(lessonId) {
    if (!$scope.playStatus) {
      return null;
    }
    for(index in $scope.playStatus) {
      playStatus = $scope.playStatus[index];
      if (playStatus.id == lessonId) {
        return playStatus;
      }
    }

    return null;
  };

  //lesson.free=1 is free
  $scope.learnClassRoomLesson = function(lesson) {
    if (!$scope.user) {
      var dia = $.dialog({
              title : '课程提醒' ,
              content : '你还未登录网校',
              button : [ "登录网校" ]
      });

      dia.on("dialog:action",function(e){
        esNativeCore.originalLogin();
      });
      return;
    }
    if (lesson.status == "unpublished") {
      alert("课时尚未发布");
      return;
    }

    if (! $scope.member && 1 != lesson.free) {
      alert("请先加入学习");
      return;
    }

    if ("chapter" == lesson.type || lesson.type == "label" || lesson.type == "unit") {
      return;
    }

    if (lesson.type == "flash" || "qqvideo" == lesson.mediaSource) {
      alert("客户端暂不支持该课时类型，敬请期待新版");
      return;
    }

    if ("live" == lesson.type && platformUtil.android) {
      cordovaUtil.openWebView(app.rootPath + "#/lesson/" + lesson.courseId + "/" + lesson.id);
      return;
    }
    if (self.findPlayStatusByLessonId(lesson.id) == null) {
      $scope.showLoad();
      CourseService.getCourse({
        courseId : lesson.courseId
      }, function(data) {
        $scope.hideLoad();
        cordovaUtil.learnCourseLesson(lesson.courseId, lesson.id, self.createLessonIds());
      });
      return;
    };
    cordovaUtil.learnCourseLesson(lesson.courseId, lesson.id, self.createLessonIds()); 
  };
};
app.controller('LoginController', ['$scope', 'UserService', '$stateParams', 'platformUtil', 'cordovaUtil', '$state', LoginController]);

function LoginController($scope, UserService, $stateParams, platformUtil, cordovaUtil, $state, $q)
{	
	console.log("LoginController");

	$scope.user = {
		username : null,
		password : null
	};

	cordovaUtil.getThirdConfig($q).then(function(data) {
		$scope.thirdConfig = data;
	});

	$scope.jumpToMain = function() {
		$state.go("slideView.mainTab");
	}

	$scope.getThirdStyle = function() {
		if (!$scope.thirdConfig || $scope.thirdConfig.length <= 1) {
			return "";
		}
		return $scope.thirdConfig.length == 2 ? "ui-grid-halve" : "ui-grid-trisect";
	}

	$scope.hasThirdType = function(name) {
		if (! $scope.thirdConfig) {
			return false;
		}

		return $scope.thirdConfig.indexOf(name) != -1;
	}

	$scope.login = function(user) {
		$scope.showLoad();
		UserService.login({
			"_username": user.username,
			"_password" : user.password
		}, function(data) {
			
		$scope.hideLoad();
			if (data.error) {
			$scope.toast(data.error.message);
			return;
		}

		if (platformUtil.native) {
			esNativeCore.closeWebView();
			return;
		}

		if ($stateParams.goto) {
			window.history.back();
		} else {
			$scope.jumpToMain();
		}
		
		});
	}

	$scope.loginWithOpen = function(type) {
		cordovaUtil.openPlatformLogin(type);
	}

	$scope.jumpToSetting = function() {
		cordovaUtil.startAppView("setting", {});
	}
};
function MainTabController($scope, sideDelegate, $state) {
    
}

app.controller('FoundTabController', ['$scope', 'CategoryService', 'AppUtil', 'sideDelegate', '$state', FoundTabController]);

function FoundTabController($scope, CategoryService, AppUtil, cordovaUtil, $state) {
    $scope.toggleView = function(view) {
        $state.go("slideView.mainTab." + view);
    };

    $scope.toggle = function() {
        
        if ($scope.platform.native) {
            return;
        }

        cordovaUtil.openDrawer("open");
    };

    $scope.categorySelectedListener = function(category) {
        cordovaUtil.openWebView(app.rootPath + "#/courselist/" + category.id);
        $(".ui-dialog").dialog("hide");
    };

    CategoryService.getCategorieTree(function(data) {
        $scope.categoryTree = data;
        $scope.openModal = function($event) {
            var dialog = $(".ui-dialog");
            dialog.dialog("show");
            $(".ui-dialog-bg").click(function(e) {
                dialog.dialog("hide");
            });
        };
    });

    var self = this;
    this.parseBannerAction = function(action) {
        this.courseAction = function(params) {
            cordovaUtil.openWebView(app.rootPath + "#/course/" + params);
        }

        this.webviewAction = function(params) {
            cordovaUtil.openWebView(params);
        }

        this.noneAction = function() {}

        return this[action + "Action"];
    }

    $scope.bannerClick = function(banner) {
        var bannerAction = self.parseBannerAction(banner.action);
        bannerAction(banner.params);
    }

    $scope.loadPage = function(pageName) {
        $scope[pageName] = 'view/found_' + pageName + '.html';
        $scope.$apply();
    }
}


app.controller('MessageTabController', ['$scope', FoundTabController]);

function MessageTabController($scope) {
}

app.controller('ContactTabController', ['$scope', ContactTabController]);

function ContactTabController($scope) {
}
;
app.controller('MyFavoriteCourseController', ['$scope', 'cordovaUtil', 'CourseService', 'CourseUtil', MyFavoriteCourseController]);
app.controller('MyFavoriteLiveController', ['$scope', 'cordovaUtil', 'CourseService', 'CourseUtil', MyFavoriteLiveController]);

function MyFavoriteBaseController($scope, cordovaUtil, CourseService, CourseUtil)
{
  var self = this;
  $scope.data  = CourseUtil.getFavoriteListTypes();

    this.loadDataList = function(type) {
      $scope.showLoad();
      var content = $scope.data[type];
      CourseService.getFavoriteCourse(
        content.url,
        {
          limit : 100,
        start: content.start
      }, function(data) {
            $scope.hideLoad();
            if (!data || data.data.length == 0) {
              content.canLoad = false;
            }

            content.data = content.data || [];
            content.data = content.data.concat(data.data);
            content.start += data.limit;

            if (data.total && content.start >= data.total) {
              content.canLoad = false;
            }
        }
      );
    }

    $scope.gotoNativeDetailCoursePage = function (courseId) {
      cordovaUtil.openNativeCourseDetailPage(courseId, "courseSet");
    };
}

function MyFavoriteCourseController($scope, cordovaUtil, CourseService, CourseUtil)
{
	this.__proto__ = new MyFavoriteBaseController($scope, cordovaUtil, CourseService, CourseUtil);

      var self = this;
      this.loadCourses = function() {
        self.loadDataList("course");
      }

      this.loadCourses();
}

function MyFavoriteLiveController($scope, cordovaUtil, CourseService, CourseUtil)
{
      this.__proto__ = new MyFavoriteBaseController($scope, cordovaUtil, CourseService, CourseUtil);

      var self = this;
      this.loadLiveCourses = function() {
        self.loadDataList("live");
      }

      this.loadLiveCourses();
};
function MyGroupBaseController($scope, serviceCallBack) {

  var self = this;
  this.limit = 10;
  $scope.data = [];
  $scope.canLoad = true;
  $scope.start = $scope.start || 0;

  this.loadDataList = function(type) {
      serviceCallBack({
        limit : self.limit,
        start: $scope.start,
        type : type
      }, function(data) {
        
        var length  = data ? data.data.length : 0;
        if (!data || length == 0 || length < self.limit) {
            $scope.canLoad = false;
          }

          $scope.data = $scope.data.concat(data.data);
          $scope.start += self.limit;
      });
    }
}

function MyGroupNoteController($scope, NoteService, cordovaUtil, $state)
{
      var self = this;
      this.__proto__ = new MyGroupBaseController($scope, NoteService.getNoteList);

    $scope.canLoadMore = function() {
      return $scope.canLoad;
    };

    $scope.loadMore = function(){
      self.loadDataList();
    };

     this.loadDataList();
}

function MyGroupQuestionController($scope, QuestionService)
{
      this.__proto__ = new MyGroupBaseController($scope, QuestionService.getCourseThreads);
  
    $scope.canLoadMore = function() {
      return $scope.canLoad;
    };

    $scope.loadMore = function(){
      self.loadDataList("question");
    };

     this.loadDataList("question");
}

function MyGroupThreadController($scope, QuestionService)
{
  this.__proto__ = new MyGroupBaseController($scope, QuestionService.getCourseThreads);

    $scope.canLoadMore = function() {
      return $scope.canLoad;
    };

    $scope.loadMore = function(){
      self.loadDataList("discussion");
    };

   this.loadDataList("discussion");
}

app.controller('MyGroupQuestionController', ['$scope', 'QuestionService', MyGroupQuestionController]);
app.controller('MyGroupNoteController', ['$scope', 'NoteService', 'cordovaUtil', '$state', MyGroupNoteController]);
app.controller('MyGroupThreadController', ['$scope', 'QuestionService', MyGroupThreadController]);;
app.controller('MyInfoController', ['$scope', 'UserService', 'cordovaUtil', 'platformUtil', '$stateParams', '$q', MyInfoController]);
function MyInfoController($scope, UserService, cordovaUtil, platformUtil, $stateParams, $q) 
{	
	var self = this;
	$scope.isChange = false;
	this.uploadAvatar = function(file) {
		
		UserService.uploadAvatar({
			file : file.files[0]
		}, function(data) {
			if (data.error) {
				$scope.toast(data.error.message);
				return;
			}

			$scope.userinfo.fileId = data.id;
			$scope.userinfo.mediumAvatar = data.url;
		});
	};

	$scope.showSelectImage = function(e) {
		e.preventDefault();
		cordovaUtil.uploadImage(
			$q,
			app.host + '/mapi_v2/User/uploadAvatar',
			{ token : $scope.token },
			{ file : "" },
			"image/*"
		).then(function(data) {
			var uploadResult = JSON.parse(data);
			if (!uploadResult) {
				alert("该功能仅支持客户端!");
				return;
			}
			$scope.userinfo.fileId = uploadResult.id;
			$scope.userinfo.mediumAvatar = uploadResult.url;

			var userinfo = $scope.userinfo;
			var params = {
				'fileId' : userinfo.fileId,
				'profile[nickname]' : userinfo.nickname,
				'profile[gender]' : userinfo.gender,
				'profile[signature]' : userinfo.signature
			};
			self.updateUserInfo(params);
		});
	};

	$scope.loadUserInfo = function() {
		$scope.showLoad();
		UserService.getUserInfo({
			userId : $scope.user.id
		}, function(data) {
			$scope.userinfo = data;
			$scope.copyForm = {
				nickname : data.nickname,
				gender : data.gender,
				signature : data.signature
			};
			if (data.signature == "null" || data.signature == null || data.signature == undefined) {
				$scope.userinfo.signature = "";
			}
			$scope.hideLoad();
		});
	};

	$scope.generArray = ['female', 'male'];

	this.updateUserInfo = function(params, callback) {
		$scope.showLoad();
		UserService.updateUserProfile(params, function(data) {
			if (data.error) {
				$scope.hideLoad();
				$scope.toast(data.error.message);
				
				return;
			}
			$scope.userinfo.fileId = "";
			$scope.toast("更新成功!");
			$scope.hideLoad();
			cordovaUtil.updateUser(data);
			
			if (callback) {
				callback();
			}
		});
	};

	$scope.updateUserProfile = function() {
		var userinfo = $scope.userinfo;
		var params = {
			'profile[nickname]' : userinfo.nickname,
			'profile[gender]' : userinfo.gender,
			'profile[signature]' : userinfo.signature
		};
		if (userinfo.fileId != "") {
			params['fileId'] = userinfo.fileId;
		}
		if (userinfo.signature == "") {
			$scope.toast("签名不能为空！");
			return
		}

		if (userinfo.nickname.indexOf(".") != -1 || userinfo.nickname.indexOf("^") != -1) {
			$scope.toast("昵称不能包含.^等特殊字符!");
			return
		}
		self.updateUserInfo(params, function() {
			cordovaUtil.backWebView();
		});
	};

	$scope.uploadChange = function(file) {
		if (file && file.value) {
			self.uploadAvatar(file);
		}
	}

	$scope.formChange = function() {
		for (key in $scope.copyForm) {
			value = $scope.copyForm[key];
			if (value != $scope.userinfo[key]) {
				$scope.isChange = true;
				return;
			}
		}
		$scope.isChange = false;
	}
};
app.controller('MyLearnController', ['$scope', 'cordovaUtil', 'CourseService', 'ClassRoomService', MyLearnController]);

function MyLearnController($scope, cordovaUtil, CourseService, ClassRoomService)
{
	var self = this;
	self.content = {
		course : {
			start : 0,
			canLoad : true,
			data : undefined
		},
		live : {
			start : 0,
			canLoad : true,
			data : undefined
		},
    classroom : {
      start : 0,
      canLoad : true,
      data : undefined
    }
	};

	$scope.course = self.content.course;
	$scope.live = self.content.live;
  $scope.classroom = self.content.classroom

  	self.loadDataList = function(content, serviceCallback, successCallback) {
      $scope.showLoad();
  		serviceCallback({
  			limit : 1000,
			start: content.start
  		}, function(data) {

        $scope.hideLoad();
        if (successCallback) {
          successCallback();
        }
  			if (!data || data.data.length == 0) {
    			content.canLoad = false;
    		}

    		content.data = content.data || [];
    		content.data = content.data.concat(data.data);
    		content.start += data.limit;

    		if (data.limit > data.data.length) {
    			content.canLoad = false;
    		}
    		if (data.total && content.start >= data.total) {
    			content.canLoad = false;
    		}
  		});
  	}
    $scope.gotoNativeDetailCoursePage = function (courseId) {
      cordovaUtil.openNativeCourseDetailPage(courseId, "course");
    };

    $scope.gotoNativeDetailClassroomPage = function (classroomId) {
      cordovaUtil.openNativeClassroomDetailPage(classroomId);
    };

  	$scope.canLoadMore = function(type) {
  		return self.content[type].canLoad;
  	};

  	$scope.loadMore = function(type, successCallback){
  		switch (type) {
  			case "course":
  				self.loadDataList(self.content.course, CourseService.getAllUserCourses, successCallback);
				break;
  			case "live":
  				self.loadDataList(self.content.live, CourseService.getLiveCourses, successCallback);
  				break;
        case "classroom":
          self.loadDataList(self.content.classroom, ClassRoomService.getLearnClassRooms, successCallback);
          break;
  		}
  	};

  	$scope.loadCourses = function() {
  		self.loadDataList(self.content.course, CourseService.getAllUserCourses);
  	}

  	$scope.loadLiveCourses = function() {
  		self.loadDataList(self.content.live, CourseService.getLiveCourses);
  	}

    $scope.loadClassRooms = function() {
      self.loadDataList(self.content.classroom, ClassRoomService.getLearnClassRooms);
    }

  	$scope.loadCourses();
}
;
app.controller('CourseCouponController', ['$scope', 'CouponService', '$stateParams', '$window', CourseCouponController]);
app.controller('VipListController', ['$scope', '$state', '$stateParams', 'SchoolService', 'cordovaUtil', VipListController]);
app.controller('VipPayController', ['$scope', '$stateParams', 'SchoolService', 'VipUtil', 'OrderService', 'cordovaUtil', 'platformUtil', VipPayController]);

function BasePayController($scope, $stateParams, OrderService, cordovaUtil, platformUtil)
{
	var self = this;
	$scope.priceType = "RMB";
	$scope.payMode = "alipay";

	this.showPayResultDlg = function() {
		var dia = $.dialog({
		        title : '确认支付' ,
		        content : '是否支付完成?' ,
		        button : [ "确认" ,"取消" ]
		});

		dia.on("dialog:action",function(e){
		        if (e.index == 0) {
		        	// window.history.closeWebView();
		        	cordovaUtil.sendNativeMessage("pay_success", {});
					cordovaUtil.closeWebView();
		        }
		});
	}

	this.initPayMode = function(data) {
		$scope.coin = data.coin;
		if (data.coin && data.coin.priceType) {
			$scope.priceType = data.coin.priceType;
			$scope.payMode = ($scope.checkIsCoinMode() || "Coin" == $scope.priceType) ? "coin" : "alipay";
		}
		$scope.orderLabel = self.getOrderLabel($stateParams.targetType);
	}

	$scope.checkIsCoinMode = function() {
		return platformUtil.ios || platformUtil.iPad;
	}

	$scope.changePayMode = function() {
		if ("Coin" == $scope.priceType) {
			return;
		}

		if ($scope.payMode == "coin") {
			$scope.payMode = "alipay";
		} else {
			$scope.payMode = "coin";
		}

		self.changePrice($scope.payMode);
	}

	this.showErrorResultDlg = function(error) {
		if ("coin_no_enough" == error.name) {
			var buttons = platformUtil.android ? [ "确认" ] : [ "确认" ,"充值" ];
			var dia = $.dialog({
			        title : '支付提醒' ,
			        content : '账户余额不足!' ,
			        button : [ "确认" ]
			});

			dia.on("dialog:action",function(e){
			        if (e.index == 1) {
			        	cordovaUtil.startAppView("rechargeCoin", null);
			        }
			});
			return;
		}
		alert(error.message);
	}

	this.getOrderLabel  = function(type) {
		switch(type) {
			case 'course':
				return "购买课程";
			case 'vip':
				return "购买会员";
			case 'classroom':
				return "购买班级";
		}

		return "";
	}

	this.payOrder = function(price, params, payPassword) {

		var payment = $scope.payMode;
		var defaultParams = {
			payment : payment,
			payPassword : payPassword ? payPassword : "",
			totalPrice : price,
			couponCode : $scope.formData ? $scope.formData.code : "",
			targetType : $stateParams.targetType,
			targetId : $stateParams.targetId
		};

		for(var i in params) {
			defaultParams[i] = params[i];
		}

		$scope.showLoad();
		OrderService.createOrder(defaultParams, function(data) {
			$scope.hideLoad();
			if ("ok" != data.status) {
				if (data.error) {
					self.showErrorResultDlg(data.error);
					return;
				}
				self.showErrorResultDlg({
					name : "error",
					message : data.message
				});
				return;
			}

			if (data.paid == true) {
				// $scope.toast("购买成功！");
				// cordovaUtil.closeWebView();
				var dia = $.dialog({
			        title : '支付提醒' ,
			        content : '您已成功购买!' ,
			        button : [ "好的" ]
				});

				dia.on("dialog:action",function(e){
					cordovaUtil.sendNativeMessage("pay_success", {});
					cordovaUtil.closeWebView();

				});
			} else if (data.payUrl != "") {
				cordovaUtil.pay($scope.orderLabel, data.payUrl);
				self.showPayResultDlg();
			}
		});
	};

	this.submitToPay = function(price, params) {
		if ($scope.payMode == "coin") {
			cordovaUtil.showInput("支付提醒", "请输入支付密码", "password", function(input) {
				if (!input || input.length == 0) {
					alert("请输入支付密码!");
					return;
				}
				self.payOrder(price, params, input);
			});
			return;
		}

		self.payOrder(price, params);
	}
}

function VipPayController($scope, $stateParams, SchoolService, VipUtil, OrderService, cordovaUtil, platformUtil)
{
	var self = this;
	$stateParams.targetType = "vip";
	$stateParams.targetId = $stateParams.levelId;
	this.__proto__ = new BasePayController($scope, $stateParams, OrderService, cordovaUtil, platformUtil);
	
	$scope.initData = function() {
		user = $scope.user;
		if (!user) {
			alert("未检查到登录用户");
			cordovaUtil.backWebView();
			return;
		}
		if (user.vip && user.vip.levelId != $stateParams.levelId) {
			alert("暂时不支持已购会员的等级调整，请到电脑端进行操作");
			cordovaUtil.backWebView();
			return;
		}
		self.loadPayOrder();
	};

	self.loadPayOrder = function() {
		$scope.showLoad();
		OrderService.getPayOrder({
			targetType : 'vip',
			targetId : $stateParams.levelId
		}, function(data) {
			$scope.data = data.orderInfo;
			self.initPayMode(data);

			$scope.payModes = VipUtil.getPayMode(data.orderInfo.buyType);
			$scope.selectedNum = 1;
			$scope.selectedPayMode = $scope.payModes[0];

			self.changePrice($scope.payMode);
			$scope.totalPayPrice = self.sumTotalPirce();
			$scope.initPopver();
			$scope.hideLoad();
		});
	}
	
	this.changePrice = function(payMode) {
		var price = self.sumTotalPirce();
		if ($scope.coin && "Coin" != $scope.priceType && payMode == "coin") {
			price = price * $scope.coin.cashRate;
		}
		if ($scope.coupon) {
			price = self.getCouponPrice(coupon, price);
		}

		$scope.totalPayPrice = price > 0 ? price : 0;
	}

	this.getCouponPrice = function(coupon, price) {
		if (coupon.type == "minus") {
			return price - coupon.rate;
		}

		if (coupon.type == "discount") {
			return price / parseFloat(coupon.rate);
		}

		return price;
	};

	$scope.changePayMode = function() {
		if ("Coin" == $scope.priceType) {
			return;
		}

		if ($scope.payMode == "coin") {
			$scope.payMode = "alipay";
		} else {
			$scope.payMode = "coin";
		}

		self.changePrice($scope.payMode);
	}

	this.sumTotalPirce = function() {
		var level = $scope.data.level;
		var payTypes = VipUtil.getPayType();

		var price = $scope.selectedPayMode.type == payTypes.byMonth ? level.monthPrice : level.yearPrice;
		var totalPayPrice = $scope.selectedNum * price;
		return totalPayPrice;
	}

	$scope.add = function() {
		if ($scope.selectedNum < 12) {
			$scope.selectedNum ++;
			$scope.totalPayPrice = self.sumTotalPirce();
			self.changePrice($scope.payMode);
		}
	}

	$scope.sub = function() {
		if ($scope.selectedNum > 1) {
			$scope.selectedNum --;
			$scope.totalPayPrice = self.sumTotalPirce();
			self.changePrice($scope.payMode);
		}
	}

	$scope.initPopver = function() {

		  $scope.showPopover = function($event) {
		  	$scope.isShowPayMode = ! $scope.isShowPayMode ;
		  };

		  $scope.selectPayMode = function(payMode) {
		  	$scope.selectedPayMode = payMode;
			$scope.totalPayPrice = self.sumTotalPirce();
		  	$scope.isShowPayMode = false;
		  }
	}

	$scope.pay = function() {
		self.submitToPay($scope.totalPayPrice, {
			duration : $scope.selectedNum,
			unitType : $scope.selectedPayMode.name
		});
	}

	$scope.payVip = function() {
		OrderService.payVip({
			targetId : $stateParams.levelId,
			duration : $scope.selectedNum,
			unitType : $scope.selectedPayMode.name
		}, function(data) {
			if (data.status == "ok" && data.payUrl != "") {
				cordovaUtil.pay("支付会员", data.payUrl);
				self.showPayResultDlg();
			} else if (data.error) {
				$scope.toast(data.error.message);
			}
		});
	}

}

function VipListController($scope, $state, $stateParams, SchoolService, cordovaUtil)
{
	var user = null;
	var self = this;
	
	$scope.loadVipList = function() {
		$scope.showLoad();
		SchoolService.getSchoolVipList({
			userId : $scope.user.id
		}, function(data) {
			$scope.hideLoad();
			if (! data || !data.vips || data.vips.length == 0) {
				var dia = $.dialog({
			        title : '会员提醒' ,
			        content : '网校尚未开启Vip服务!' ,
			        button : [ "退出" ]
				});

				dia.on("dialog:action",function(e){
					cordovaUtil.closeWebView();
				});
			}
			data.vips.sort(function(a,b) {
				return b.seq - a.seq;
			});
			$scope.data = data;
			user = data.user;
		});
	}

	self.getCurrentVipLevel = function(levelId, levelList) {
		if (levelId <= 0) {
			return null;
		}
		for (var i = 0; i < levelList.length; i++) {
			if (levelId == levelList[i].id) {
				return levelList[i];
			}
		};

		return null;
	};
/*
	$scope.setVIPcardBGbyType = function( vipTypeSeq){
		if(vipTypeSeq == 1){
			$("#cardp1").addClass("vip-level1");
			$("#cardp2").addClass("vip-level1");
		}
		if(vipTypeSeq == 2){
			$("#cardp1").addClass("vip-level2");
			$("#cardp2").addClass("vip-level2");
	
			
		}
		if(vipTypeSeq == 3){
			$("#cardp1").addClass("vip-level3");
			$("#cardp2").addClass("vip-level3");
			
		}
			
		
		
	}
*/
	$scope.getVipName = function() {
		if (!$scope.data) {
			return "";
		}

		if (!user || !user.vip) {
			return "暂时还不是会员";
		}
		var levelId = user.vip.levelId;
		var vips = $scope.data.vips;

		currentLevel = self.getCurrentVipLevel(levelId, vips);
		if (!currentLevel) {
			return "暂时还不是会员";
		}

		return "等级:" + currentLevel.name;
	}

	$scope.showPayVipPage = function(targetLevel) {
		if (!$scope.data) {
			return;
		}

		if (!user || !user.vip) {
			$state.go("vipPay", { "levelId" : targetLevel.id})
			return;
		}
		var levelId = user.vip.levelId;
		var vips = $scope.data.vips;
		currentLevel = self.getCurrentVipLevel(levelId, vips);
		if (!currentLevel) {
			$state.go("vipPay", { "levelId" : targetLevel.id})
			return;
		}
		if (currentLevel.id != targetLevel.id) {
			alert("暂时不支持已购会员的等级调整，请到电脑端进行操作");
			return;
		}
		$state.go("vipPay", { "levelId" : targetLevel.id});
	};
}

function CourseCouponController($scope, CouponService, $stateParams, $window)
{	
	$scope.formData = { code : "" };
	$scope.checkCoupon = function() {
		$scope.formData.error = "";
		$scope.showLoad();
		CouponService.checkCoupon({
			courseId : $stateParams.courseId,
			type : "course",
			code : $scope.formData.code
		}, function(data) {
			$scope.hideLoad();
			if (data.meta.code != 200) {
				$scope.formData.error = "优惠码不存在或已使用";
				return;
			}
			$window.history.back();
			$scope.$emit("coupon", { coupon : data.data });
		}, function(data) {
			$scope.hideLoad();
			$scope.toast("检验优惠码错误");
		});
	}
}

app.controller('CoursePayController', ['$scope', '$stateParams', 'OrderService', 'CouponService', 'AppUtil', 'cordovaUtil', 'platformUtil', CoursePayController]);
function CoursePayController($scope, $stateParams, OrderService, CouponService, AppUtil, cordovaUtil, platformUtil)
{	
	var self = this;
	this.__proto__ = new BasePayController($scope, $stateParams, OrderService, cordovaUtil, platformUtil);

	this.loadOrder = function() {
		$scope.showLoad();
		OrderService.getPayOrder({
			targetType : $stateParams.targetType,
			targetId : $stateParams.targetId
		}, function(data) {
			$scope.hideLoad();
			$scope.data = data;
			self.initPayMode(data);
			self.changePrice($scope.payMode);
		});
	};

	$scope.$parent.$on("coupon", function(event, data) {
		$scope.coupon = data.coupon;
		self.changePrice($scope.payMode);
	});

	this.changePrice = function(payMode) {
		var price = $scope.data.orderInfo.price;
		if ($scope.coin  && payMode == "coin") {
			price = price * $scope.coin.cashRate;
		}
		if ($scope.coupon) {
			price = self.getCouponPrice($scope.coupon, price);
		}
		$scope.payPrice = price > 0 ? price : 0;
	}

	this.getCouponPrice = function(coupon, price) {
		if (coupon.type == "minus") {
			return price - coupon.rate;
		}

		if (coupon.type == "discount") {
			return price / parseFloat(coupon.rate);
		}

		return price;
	};

	$scope.selectCoupon = function() {
		$scope.formData = { code : "", error : '' };
		self.dialog = $(".ui-dialog");
		self.dialog.dialog("show");
	}

	$scope.changePayMode = function() {
		if ("Coin" == $scope.priceType) {
			return;
		}

		if ($scope.payMode == "coin") {
			$scope.payMode = "alipay";
		} else {
			$scope.payMode = "coin";
		}

		self.changePrice($scope.payMode);
	}

	$scope.pay = function() {
		self.submitToPay($scope.data.orderInfo.price, null);
	}

	$scope.checkCoupon = function() {
		if ($scope.formData.code.length <= 0) {
			alert("请输入优惠码");
			return;
		}

		$scope.showLoad();
		CouponService.checkCoupon({
			courseId : $stateParams.courseId,
			type : "course",
			code : $scope.formData.code
		}, function(data) {
			$scope.hideLoad();
			if (data.error) {
				$scope.formData.error = "优惠码不存在或已使用";
				return;
			}
			$scope.$emit("coupon", { coupon : data });
			$scope.close();

		}, function(data) {
			$scope.hideLoad();
			$scope.toast("检验优惠码错误");
		});
	}

	$scope.close = function() {
		self.dialog.dialog("hide");
	}

	$scope.isShowCoupon = function() {
		if (platformUtil.native && (platformUtil.iPhone || platformUtil.iPad)) {
			return false;
		}
		if ($scope.data && $scope.data.isInstalledCoupon) {
			return true;
		}
		return false;
	};

	self.loadOrder();
}
;
app.controller('QuestionController', ['$scope', 'QuestionService', '$stateParams', QuestionController]);
app.controller('NoteController', ['$scope', 'NoteService', '$stateParams', NoteController]);

function QuestionController($scope, QuestionService, $stateParams)
{	
	var self = this;
	this.loadQuestion = function() {
		$scope.showLoad();
		QuestionService.getThread({
			courseId: $stateParams.courseId,
			threadId : $stateParams.threadId
		}, function(data) {
			$scope.thread = data;
			$scope.hideLoad();

			self.loadTeacherPost();
			self.loadTheadPost();
		});
	}
	
	this.loadTeacherPost = function() {
		QuestionService.getThreadTeacherPost({
			courseId: $stateParams.courseId,
			threadId : $stateParams.threadId
		}, function(data) {
			$scope.teacherPosts = data;
		});
	}

	this.loadTheadPost = function() {
		QuestionService.getThreadPost({
			courseId: $stateParams.courseId,
			threadId : $stateParams.threadId
		}, function(data) {
			$scope.threadPosts = data.data;
		});
	}

	self.loadQuestion();
}

function NoteController($scope, NoteService, $stateParams)
{	
	var self = this;
	this.loadNote = function() {
		$scope.showLoad();
		NoteService.getNote({
			noteId: $stateParams.noteId
		}, function(data) {
			$scope.note = data;
			$scope.hideLoad();
		});
	}

	self.loadNote();
};
app.controller('RegistController', ['$scope', 'platformUtil', 'UserService', '$state', 'localStore', RegistController]);

function RegistController($scope, platformUtil, UserService, $state, localStore)
{
	$scope.user = {
		phone : null,
		code : null,
		password: null
	};

	var self = this;

	this.registHandler = function(params) {
		$scope.showLoad();
		UserService.regist(params, function(data) {
			$scope.hideLoad();
			if (data.error) {
				$scope.toast(data.error.message);
				return;
			}
			if (platformUtil.native) {
				esNativeCore.closeWebView();
				return;
			}
			self.jumpToMain();
		}, function(error) {
			$scope.toast("注册不成功，请联系网校管理员！");
		});
	}

	this.jumpToMain = function() {
		$state.go("slideView.mainTab");
	}

	$scope.checkCode = function(code) {
		return !code || code.length == 0;
	};

	$scope.sendSmsCode = function(phone) {
		if (!parseInt(phone)) {
			alert("您尚未输入手机号码，请检查后输入!");
			return;
		}
		var reg = new RegExp(/0?(13|14|15|18)[0-9]{9}/);
		if (reg.test(phone) != true) {
			alert("您输入的手机号码格式不正确，请检查后重新输入");
			return;
		};

		var lasterSmsSendTime = localStore.get("lasterSmsSendTime");
		console.log(new Date().getTime() - lasterSmsSendTime);
		if ((new Date().getTime() - lasterSmsSendTime) < 120000) {
			$scope.toast("请等待120s后重发");
			return;
		}
		$scope.showLoad();
		UserService.smsSend({
			phoneNumber : phone
		}, function(data) {
			$scope.hideLoad();
			if (data.code == 200) {
				localStore.save("lasterSmsSendTime", new Date().getTime());
				$scope.toast(data.msg);
				return;
			}
			$scope.toast(data.error.message);
		});
	}

	$scope.registWithPhone = function(user) {
		if (!parseInt(user.phone)) {
			alert("您尚未输入手机号码，请检查后输入!");
			return;
		}
		var phoneReg = new RegExp(/0?(13|14|15|18)[0-9]{9}/);
		if (phoneReg.test(user.phone) != true) {
			alert("您输入的手机号码格式不正确，请检查后重新输入");
			return;
		};
		if (!user.password || (user.password.length < 5 || user.password.length > 20)) {
			alert("密码格式为：长度为5-20位字符，区分大小写，请检查后重新输入!");
			return;
		}

		if ($scope.checkCode(user.code)) {
			alert("验证码不正确!");
			return;
		}
		self.registHandler({
			registeredWay : platformUtil.android ? "android" : "ios", 
			phone : user.phone,
			smsCode : user.code,
			password : user.password,
		});
	}

	$scope.registWithEmail = function(user) {
		if (!user.email) {
			alert("您尚未输入邮箱，请检查后重新输入");
			return;
		}
		var emailReg = new RegExp(/\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/);
		if (emailReg.test(user.email) != true) {
			alert("提示邮箱格式不正确！");
			return;
		};
		if (!user.password || (user.password.length < 5 || user.password.length > 20)) {
			alert("密码格式为：长度为5-20位字符，区分大小写，请检查后重新输入");
			return;
		}
		self.registHandler({
			registeredWay : platformUtil.android ? "android" : "ios", 
			email : user.email,
			password : user.password,
		});
	}
};
app.controller('SearchController', ['$scope', 'CourseService', 'ClassRoomService', 'cordovaUtil', '$timeout', SearchController]);

function SearchController($scope, CourseService, ClassRoomService, cordovaUtil, $timeout, $location)
{
	$scope.search = "";
	var self = this;
    var query = $location.$$search;
    $scope.shouldShowStudentNum = query.shouldShowStudentNum;
	$scope.focusSearchInput = function() {
		$('.ui-searchbar-wrap').addClass('focus');
        $('.ui-searchbar-input input').focus();
        esNativeCore.showKeyInput();
	};

	$scope.inputKeyPress = function($event) {
		if ($event.keyCode == 13 && $scope.search.length > 0) {
			self.search();
		}
	};

	$scope.seach = function() {
		if ($scope.search.length == 0) {
			cordovaUtil.closeWebView();
			return;
		}
		self.search();
	};

	this.initSearch = function() {
		self.content = {
			course : {
				start : 0,
				canLoad : true,
				total : 0,
				data : undefined
			},
		    classroom : {
		      start : 0,
		      canLoad : true,
		      total : 0,
		      data : undefined
		    }
		};

		$scope.searchCourse = self.content.course;
		$scope.searchClassRoom = self.content.classroom;
	};

	this.search = function() {
		$('.ui-searchbar-input input').blur();
		$scope.showLoad();
		self.initSearch();
		self.loadSearchCourses(5, self.content.course);
		self.loadSearchClassrooms(5, self.content.classroom);
	};

	this.loadSearchCourses = function(limit, content) {
          CourseService.searchCourse({
            limit : limit,
            offset: content.start,
            title : $scope.search
          }, function(data) {
            $scope.hideLoad();
            var length  = data ? data.data.length : 0;
            content.canLoad = ! (! data || length < 10);

            content.data = content.data || [];
            for (var i = 0; i < length; i++) {
              content.data.push(data.data[i]);
            };

            content.total = data.paging.total;
            content.start += data.paging.limit;
            $scope.searchCourse = content;
            $scope.$apply();
          });
  };

  this.loadSearchClassrooms = function(limit, content) {
  	ClassRoomService.search({
  		limit : limit,
  		start : content.start,
  		title : $scope.search
  	}, function(data) {
  		$scope.hideLoad();
	    var length  = data ? data.data.length : 0;
	    content.canLoad = ! (! data || length < 10);

	    content.data = content.data || [];
	    for (var i = 0; i < length; i++) {
	      content.data.push(data.data[i]);
	    };

	    content.total = data.total;
	    content.start += data.limit;
	    $scope.searchClassRoom = content;
  	});
  }

  $scope.gotoNativeDetailCoursePage = function (courseId) {
      cordovaUtil.openNativeCourseDetailPage(courseId, "courseSet");
  };

  $scope.gotoNativeDetailClassroomPage = function (classroomId) {
      cordovaUtil.openNativeClassroomDetailPage(classroomId);
  };
}

app.controller('SearchCourseResultController', ['$scope', '$stateParams', 'CourseService', 'ClassRoomService', 'cordovaUtil', '$timeout', SearchCourseResultController]);

function SearchCourseResultController($scope, $stateParams, CourseService, ClassRoomService, cordovaUtil, $timeout, $location) {
	this.__proto__ = new SearchController($scope, CourseService, ClassRoomService, cordovaUtil, $timeout, $location);

	$scope.search = $stateParams.search;
	$scope.showLoad();
	this.initSearch();
	this.loadSearchCourses(100, this.content.course);
	$scope.gotoNativeDetailCoursePage = function (courseId) {
      cordovaUtil.openNativeCourseDetailPage(courseId, "courseSet");
    };
}

app.controller('SearchClassRoomResultController', ['$scope', '$stateParams', 'CourseService', 'ClassRoomService', 'cordovaUtil', '$timeout', SearchClassRoomResultController]);

function SearchClassRoomResultController($scope, $stateParams, CourseService, ClassRoomService, cordovaUtil, $timeout, $location) {
	this.__proto__ = new SearchController($scope, CourseService, ClassRoomService, cordovaUtil, $timeout, $location);

	$scope.search = $stateParams.search;
	$scope.showLoad();
	this.initSearch();
	this.loadSearchClassrooms(100, this.content.classroom);
	$scope.gotoNativeDetailClassroomPage = function (classroomId) {
      cordovaUtil.openNativeClassroomDetailPage(classroomId);
    };
};
app.controller('SettingController', ['$scope', 'UserService', '$state', SettingController]);

function SettingController($scope, UserService, $state)
{
	$scope.isShowLogoutBtn = $scope.user ? true : false;
	$scope.logout = function() {
		$scope.showLoad();
		UserService.logout( {}, function(data) {
			$scope.hideLoad();
			$state.go("slideView.mainTab");
		});
	}
};
app.controller('StudentListController', ['$scope', 'ClassRoomService', 'CourseService', '$stateParams', StudentListController]);
function StudentListController($scope, ClassRoomService, CourseService, $stateParams)
{
	$scope.title = getTitle($stateParams.targetType);

	function getTitle(targetType) {
		if ("classroom" == $stateParams.targetType) {
			return "班级学员";
		}

		return "课程学员";
	}

	function getEmptyStr(targetType) {
		if ("classroom" == $stateParams.targetType) {
			return "该班级暂无学员";
		}

		return "该课程暂无学员";
	}

	$scope.canLoad = true;
    $scope.start = $scope.start || 0;

	$scope.title = getTitle($stateParams.targetType);
	$scope.emptyStr = getEmptyStr($stateParams.targetType);

	$scope.loadMore = function(successCallback){
        if (! $scope.canLoad) {
        	if (successCallback) {
        		successCallback();
        	};
            return;
        }
        setTimeout(function() {
        	$scope.loadUsers(successCallback);
        }, 200);
    };

	function getClassRoomStudents(targetId, callback) {
		ClassRoomService.getStudents({
			start : $scope.start,
			classRoomId : $stateParams.targetId
		}, callback);
	}

	function getCourseStudents(targetId, callback) {
		CourseService.getStudents({
			offset : $scope.start,
			courseId : $stateParams.targetId,
		}, callback);
	}

	function getCourseSetStudents(targetId, callback) {
    CourseService.getSetStudents({
            offset : $scope.start,
    }, callback, null, targetId);
  }

	function getStudentArray(resources) {
		var users = [];
		for (var i = 0; i < resources.length; i++) {
			if (resources[i].user) {
				users[i] = resources[i].user;
			} else {
				users[i] = resources[i];
			}
		};

		return users;
	}

	$scope.loadUsers = function(successCallback) {
		var service;
		if ("classroom" == $stateParams.targetType) {
			service = getClassRoomStudents;
		} else if ("course" == $stateParams.targetType){
			service = getCourseStudents;
		} else {
			service = getCourseSetStudents;
		}
		service($stateParams.targetId, function(data) {
			if (successCallback) {
				successCallback();
			}
			var users = [];
			if ('courseset' == $stateParams.targetType) {
				length = data ? data.length : 0;
				users = getStudentArray(data);
			} else if ("course" == $stateParams.targetType) {
				length = data ? data.data.length : 0;
				users = getStudentArray(data.data);
			} else  {
				length = data ? data.resources.length : 0;
				users = getStudentArray(data.resources);
			}
			if (length == 0 || length < 10) {
				$scope.canLoad = false;
			}
			$scope.users = $scope.users || [];
			for (var i = 0; i < length; i++) {
				$scope.users.push(users[i]);
			};
			$scope.start += 10;
		});
	}

	$scope.getUserAvatar = function(user) {
		if (user.mediumAvatar) {
			return user.mediumAvatar;
		}
		if (user.avatar.middle) {
			return user.avatar.middle;
		}
		if (user.avatar) {
			return user.avatar;
		}
		return "";
	}
};
app.controller('TeacherListController', ['$scope', 'UserService', 'ClassRoomService', '$stateParams', TeacherListController]);

function TeacherListController($scope, UserService, ClassRoomService, $stateParams)
{
	$scope.title = "课程教师";
	$scope.emptyStr = "该课程暂无教师";
	var self = this;
	this.initService = function() {
		if ("course" == $stateParams.targetType) {
			self.targetService = self.loadCourseTeachers;
		} else if ("classroom" == $stateParams.targetType) {
			$scope.title = "班级教师";
			$scope.emptyStr = "该班级暂无教师";
			self.targetService = self.loadClassRoomTeachers;
		}
	};

	this.loadClassRoomTeachers = function() {
		ClassRoomService.getTeachers({
			limit : 10000,
			classRoomId : $stateParams.targetId
		}, function(data) {
			$scope.users = data;
		});
	};

	this.loadCourseTeachers = function() {
		UserService.getCourseTeachers({
			limit : 10000,
			courseId : $stateParams.targetId
		}, function(data) {
			$scope.users = data;
		});
	};

	$scope.loadUsers = function() {
		self.targetService();
	}

	$scope.getUserAvatar = function(user) {
		if (user.avatar) {
			return user.avatar;
		}

		if (user.mediumAvatar) {
			return user.mediumAvatar;
		}

		return "";
	}

	this.initService();
};
function BaseToolController($scope, OrderService, UserService, cordovaUtil)
{
  var self = this;

  this.canVipLeand = function(vipLevelId) {
    if($scope.vipLevels.length <= 0 || vipLevelId <= 0){
      return false;
    }
    
    return true;
  }

  this.payCourse = function(price, targetType, targetId) {
      $scope.showLoad("正在加入...");
      OrderService.createOrder({
        payment : "alipay",
        payPassword : "",
        totalPrice : price,
        couponCode : "",
        targetType : targetType,
        targetId : targetId
      }, function(data) {
        $scope.hideLoad();
        if (data.paid == true) {
          window.location.reload();
        } else {
          var error = "加入学习失败";
          if (data.error) {
            error = data.error.message;
          }
          $scope.toast(error);
        }
      }, function(error) {
        $scope.toast("加入失败");
        $scope.hideLoad();
      });
    }

  this.vipLeand = function(vipLevelId, callback) {
    if ($scope.user == null) {
      esNativeCore.originalLogin();
      return;
    }
    
    $scope.showLoad();
    UserService.getUserInfo({
      userId : $scope.user.id,
    }, function(data) {
      $scope.hideLoad();
      if (data.vip == null || data.vip.levelId < vipLevelId) {
        callback();
      } else {
        callback();
      }
    }, function(error) {
      $scope.toast("获取用户信息失败!");
    });
  }

  this.join = function(callback) {
      if ($scope.user == null) {
        esNativeCore.originalLogin();
        return;
      }

      callback();
  }

  $scope.getJoinBtnCls = function(targetStatus) {
    var cls = "";
    var isCanShowConsultBtn = $scope.isCanShowConsultBtn();
    cls += isCanShowConsultBtn ? "btn-col-45" : "btn-col-75";
    cls += "closed" != targetStatus ? " btn-yellow" : " btn-gray";

    return cls;
  };

  $scope.isCanShowConsultBtn = function() {
      if ($scope.course && "classroom" == $scope.course.source) {
        return false;
      }

      if (!$scope.teachers || $scope.teachers.length == 0) {
        return false;
      }

      return true;
  };

  $scope.consultCourseTeacher = function() {
    if ($scope.user == null) {
      esNativeCore.originalLogin();
      return;
    }
    if (!$scope.teachers || $scope.teachers.length == 0) {
      alert("该课程暂无教师");
      return;
    }

    var userId = $scope.teachers[0].id;
    $scope.showLoad();
    cordovaUtil.startAppView("courseConsult", { userId : userId });
    setTimeout(function() {
      $scope.hideLoad();
    }, 1500);
  };

  $scope.postQuestion = function(targetType, targetId, type) {
      var threadType = "course";
      if (targetType == "classroom") {
        threadType = "common";
      }
      cordovaUtil.startAppView("threadCreate", {
        targetId : targetId,
        targetType : targetType,
        threadType : threadType,
        type : type ? type : "question"
      });
  };

  $scope.continueLearnCourse = function() {
      $scope.$root.$emit("continueLearnCourse", {});
  };

  $scope.$root.$on("initLearnBtnStatus", function(event, data) {
    $scope.lastIndex = data.lastIndex;
  });

  $scope.$root.$on("tabClick", function(event, data) {
    $scope.currentPage = data.index;
    $scope.$apply();
  });
}

app.controller('CourseToolController', ['$scope', '$stateParams', 'OrderService', 'CourseService', 'UserService', 'cordovaUtil', '$state', CourseToolController]);
function CourseToolController($scope, $stateParams, OrderService, CourseService, UserService, cordovaUtil, $state)
{
    this.__proto__ = new BaseToolController($scope, OrderService, UserService, cordovaUtil);
    var self = this;

    $scope.userVipLevel = 0;
    if ($scope.user) {
      UserService.getUserInfo({
        userId: $scope.user.id,
      }, function (data) {
        if (data.vip != null) {
          $scope.userVipLevel = data.vip.levelId;
        }
      });
    }

    this.goToPay = function() {
      var course = $scope.course;
      var price = course.price;
      if (price <= 0) {
        self.payCourse(price, "course", $stateParams.courseId);
      } else {
        if (self.canVipLeand($scope.course.vipLevelId)) {
          self.vipLeandCourse(function() {
            $state.go("coursePay", { targetId : $scope.course.id, targetType : 'course' });
          });
          return;
        }
        $state.go("coursePay", { targetId : $scope.course.id, targetType : 'course' });
      }
    };

    this.checkModifyUserInfo = function(modifyInfos) {
      for (var i = 0; i < modifyInfos.length; i++) {
        var modifyInfo = modifyInfos[i];
        if (!modifyInfo["content"] || modifyInfo["content"] == 0) {
          alert("请填写" + modifyInfo["title"]);
          return false;
        }
      };

      return true;
    }

    $scope.$parent.updateModifyInfo = function() {
      var modifyInfos = $scope.$parent.modifyInfos;
      if (!self.checkModifyUserInfo(modifyInfos)) {
        return;
      }
      $scope.showLoad()
      CourseService.updateModifyInfo({
        targetId : $scope.course.id
      }, function(data) {
        $scope.hideLoad();
        if (data.error) {
          $scope.toast(data.error.message);
          return;
        }
        if (true == data) {
          self.goToPay();
        }
      });
    };

    this.getModifyUserInfo = function(success) {
      $scope.$parent.close = function() {
        self.dialog.dialog("hide");
      }

      CourseService.getModifyInfo({}, function(data) {

        if(true != data["buy_fill_userinfo"]) {
          success();
          return
        }

        $scope.$parent.modifyInfos = data["modifyInfos"];
        if (data["modifyInfos"].length > 0) {
          self.dialog = $(".ui-dialog");
          self.dialog.dialog("show");
        } else {
          success();
        }
      });
    };

    self.vipLeandCourse = function(errorCallback) {
      self.vipLeand($scope.course.vipLevelId, function() {
        CourseService.vipLearn({
          courseId : $stateParams.courseId
        }, function(data){
          if (! data.error) {
            window.location.reload();
          } else {
            $scope.toast(data.error.message);
            errorCallback();
          }
        }, function(error) {
          errorCallback();
        });
      });
    }

    $scope.joinCourse = function() {
      if ($scope.course.status == 'closed') {
        alert("课程已关闭!");
        return;
      }

      if ($scope.course.buyable != 1 && $scope.course.status == 'published') {
        alert("该课程限制加入，请联系管理员");
        return;
      }

      if ($scope.course.buyable != 1 && $scope.course.status != 'published') {
        alert("该课程限制加入，请联系管理员");
        return;
      }

      if ($scope.course.buyable != 1 && $scope.course.vipLevelId > 0 && $scope.userVipLevel < $scope.course.vipLevelId) {
        alert("该课程为会员课程，成为会员免费学习");
        return;
      }

      self.join(function() {
        self.goToPay();
      });

    }

    $scope.joinButtonTitle = function () {
      if ($scope.user == null) {
        return '加入课程';
      }
      if ($scope.course.status == 'closed') {
        return '课程以关闭';
      }
      if ($scope.user.vip == null || $scope.user.vip.levelId < $scope.course.vipLevelId ) {
        if ($scope.course.price > 0.00)
          return '购买课程';
      }
      return '加入课程';
    }
}

app.controller('ClassRoomToolController', ['$scope', '$stateParams', 'OrderService', 'ClassRoomService', 'UserService', 'cordovaUtil', '$state', ClassRoomToolController]);

function ClassRoomToolController($scope, $stateParams, OrderService, ClassRoomService, UserService, cordovaUtil, $state)
{
  this.__proto__ = new BaseToolController($scope, OrderService, UserService, cordovaUtil);
    var self = this;

    $scope.userVipLevel = 0;
    if ($scope.user) {
      UserService.getUserInfo({
        userId: $scope.user.id,
      }, function (data) {
        if (data.vip != null) {
          $scope.userVipLevel = data.vip.levelId;
        }
      });
    }

    $scope.signDate = new Date();
    this.goToPay = function() {
      var classRoom = $scope.classRoom;
      var price = classRoom.price;
      if (price <= 0) {
        self.payCourse(price, "classroom", $stateParams.classRoomId);
      } else {
        $state.go("coursePay", { targetId : $scope.classRoom.id, targetType : 'classroom' });
      }
    };

    $scope.sign = function() {
      if ($scope.signInfo && $scope.signInfo.isSignedToday) {
        $scope.toast("今天已经签到了!");
        return;
      }
      ClassRoomService.sign({
        classRoomId : $stateParams.classRoomId
      }, function(data) {
        if(data.error) {
          $scope.toast(data.error.message);
          return;
        }

        $scope.signInfo = data;
      });
    }

    $scope.joinClassroom = function() {
      if ($scope.classRoom.status == 'closed') {
        alert("班级已关闭!");
        return;
      }

      if ($scope.classRoom.buyable != 1 && $scope.classRoom.status == 'published') {
        alert("该班级限制加入，请联系管理员");
        return;
      }

      if ($scope.classRoom.buyable != 1 && $scope.classRoom.status != 'published') {
        alert("该班级限制加入，请联系管理员");
        return;
      }

      if ($scope.classRoom.buyable != 1 && $scope.classRoom.vipLevelId > 0 && $scope.userVipLevel < $scope.classRoom.vipLevelId) {
        alert("该课程为会员课程，成为会员免费学习");
        return;
      }
      
      self.join(function() {
        self.goToPay();
      });
    }

    $scope.getTodaySignInfo = function() {
      ClassRoomService.getTodaySignInfo({
        classRoomId : $stateParams.classRoomId
      }, function(data) {
        $scope.signInfo = data;
      });
    };

    $scope.learnByVip = function() {
      self.vipLeand($scope.classRoom.vipLevelId, function() {
        ClassRoomService.learnByVip({
          classRoomId : $stateParams.classRoomId
        }, function(data){
          if (! data.error) {
            window.location.reload();
          } else {
            $scope.toast(data.error.message);
          }
        }, function(error) {
        });
      });
    }
}
;
app.controller('TeacherListController', ['$scope', 'cordovaUtil', 'UserService', 'ClassRoomService', '$stateParams', TeacherListController]);
app.controller('UserInfoController', ['$scope', 'UserService', '$stateParams', 'AppUtil', 'cordovaUtil', UserInfoController]);
app.controller('StudentListController', ['$scope', 'ClassRoomService', 'CourseService', '$stateParams', StudentListController]);

function TeacherListController($scope, cordovaUtil, UserService, ClassRoomService, $stateParams) {
	$scope.title = "课程教师";
	$scope.emptyStr = "该课程暂无教师";
	var self = this;
	this.initService = function() {
		if ("course" == $stateParams.targetType) {
			self.targetService = self.loadCourseTeachers;
		} else if ("classroom" == $stateParams.targetType) {
			$scope.title = "班级教师";
			$scope.emptyStr = "该班级暂无教师";
			self.targetService = self.loadClassRoomTeachers;
		}
	};

	this.loadClassRoomTeachers = function() {
		ClassRoomService.getTeachers({
			limit: 10000,
			classRoomId: $stateParams.targetId
		}, function(data) {
			$scope.users = data;
		});
	};

	this.loadCourseTeachers = function() {
		UserService.getCourseTeachers({
			limit: 10000,
			courseId: $stateParams.targetId
		}, function(data) {
			$scope.users = data;
		});
	};

	$scope.loadUsers = function() {
		self.targetService();
	}

	$scope.getUserAvatar = function(user) {
		if (user.avatar) {
			return user.avatar;
		}

		if (user.mediumAvatar) {
			return user.mediumAvatar;
		}

		return "";
	}

	this.initService();
}

function StudentListController($scope, ClassRoomService, CourseService, $stateParams) {
	$scope.title = getTitle($stateParams.targetType);

	function getTitle(targetType) {
		if ("classroom" == $stateParams.targetType) {
			return "班级学员";
		}

		return "课程学员";
	}

	function getEmptyStr(targetType) {
		if ("classroom" == $stateParams.targetType) {
			return "该班级暂无学员";
		}

		return "该课程暂无学员";
	}

	$scope.canLoad = true;
	$scope.start = $scope.start || 0;
	$scope.title = getTitle($stateParams.targetType);
	$scope.emptyStr = getEmptyStr($stateParams.targetType);

	$scope.loadMore = function(successCallback) {
		if (!$scope.canLoad) {
			if (successCallback) {
				successCallback();
			}
			return;

		}
		setTimeout(function() {
			$scope.loadUsers(successCallback);
		}, 200);
	};

	function getClassRoomStudents(targetId, callback) {
		ClassRoomService.getStudents({
			start: $scope.start,
			classRoomId: $stateParams.targetId
		}, callback);
	}

	function getCourseStudents(targetId, callback) {
		CourseService.getStudents({
			offset: $scope.start,
			limit: 10,
			courseId: $stateParams.targetId,
		}, callback);
	}

	function getCourseSetStudents(targetId, callback) {
		CourseService.getSetStudents({
			offset: $scope.start
		}, callback, null, targetId);
	}

	function getStudentArray(resources) {
		var users = [];
		for (var i = 0; i < resources.length; i++) {
			if (resources[i].user) {
				users[i] = resources[i].user;
			} else {
				users[i] = resources[i];
			}
		};

		return users;
	}

	$scope.loadUsers = function(successCallback) {
		var service;
		var length;
		if ("classroom" == $stateParams.targetType) {
			service = getClassRoomStudents;
		} else if ("course" == $stateParams.targetType) {
			service = getCourseStudents;
		} else {
			service = getCourseSetStudents;
		}
		service($stateParams.targetId, function(data) {
			if (successCallback) {
				successCallback();
			}
			var users = [];
			if ('courseset' == $stateParams.targetType) {
				length = data ? data.length : 0;
				users = getStudentArray(data);
			} else if ("course" == $stateParams.targetType) {
				length = data ? data.data.length : 0;
				users = getStudentArray(data.data);
			} else  {
				length = data ? data.resources.length : 0;
				users = getStudentArray(data.resources);
			}
			if (length == 0 || length < 10) {
				$scope.canLoad = false;
			}
			$scope.users = $scope.users || [];
			for (var i = 0; i < length; i++) {
				$scope.users.push(users[i]);
			};
			$scope.start += 10;
		});
	}

	$scope.getUserAvatar = function(user) {
		if (user.mediumAvatar) {
			return user.mediumAvatar;
		}
		if (user.avatar.middle) {
			return user.avatar.middle;
		}

		if (user.avatar) {
			return user.avatar;
		}
		return "";
	}
}

function UserInfoController($scope, UserService, $stateParams, AppUtil, cordovaUtil) {
	var self = this;
	$scope.canLoad = true;
	$scope.start = $scope.start || 0;
	$scope.isFollower = null;
	$scope.uiBarTransparent = true;

	$scope.loadMore = function(successCallback) {

		if (!$scope.canLoad) {

			if (successCallback) {
				successCallback();
			}
			return;
		}

		$scope.loadData(successCallback);
	};

	$scope.loadData = function(successCallback) {
		if ($scope.isTeacher) {
			self.getUserTeachCourse(successCallback);
		} else {
			self.getUserLearnCourse(successCallback);
		}

	}

	$scope.changeTabStatus = function(headTop, scrollTop) {
		var transparent = scrollTop < headTop;
		if (transparent == $scope.uiBarTransparent) {
			return;
		}

		$scope.$apply(function() {
			$scope.uiBarTransparent = transparent;
		});
	}

	this.isTeacher = function(role) {
		return AppUtil.inArray('ROLE_TEACHER', role) > 0;
	}

	$scope.getEmptyTitle = function() {
		return "暂无课程数据";
	}

	this.getUserLearnCourse = function(successCallback) {
		UserService.getLearningCourseWithoutToken({
			userId: $stateParams.userId,
			start: $scope.start,
			limit: 10
		}, function(data) {
			if (successCallback) {
				successCallback();
			}
			var length = data ? data.data.length : 0;
			if (!data || length == 0 || length < 10) {
				$scope.canLoad = false;
			}
			$scope.courses = $scope.courses || [];
			for (var i = 0; i < length; i++) {
				$scope.courses.push(data.data[i]);
			}
			var limitNumber = parseInt(data.limit);
			$scope.start += limitNumber;
		});
	}

	this.getUserTeachCourse = function(successCallback) {
		UserService.getUserTeachCourse({
			userId: $stateParams.userId,
			start: $scope.start,
			limit: 10
		}, function(data) {
			if (successCallback) {
				successCallback();
			}
			var length = data ? data.data.length : 0;
			if (!data || length == 0 || length < 10) {
				$scope.canLoad = false;
			}
			$scope.courses = $scope.courses || [];
			for (var i = 0; i < length; i++) {
				$scope.courses.push(data.data[i]);
			}
			var limitNumber = parseInt(data.limit);
			$scope.start += limitNumber;
		});
	}

	$scope.isUnOwner = function() {

		if ($scope.user && $scope.user.id == $stateParams.userId) {
			return false;
		}

		return true;
	};

	$scope.loadUserInfo = function() {
		$scope.showLoad();
		UserService.getUserInfo({
			userId: $stateParams.userId
		}, function(data) {
			$scope.hideLoad();
			if (!data) {
				$scope.toast("获取用户信息失败！");
				return;
			}
			$scope.userinfo = data;
			$scope.isTeacher = self.isTeacher(data.roles);
			if ($scope.isTeacher) {
				self.getUserTeachCourse();
			} else {
				self.getUserLearnCourse();
			}

			if ($scope.user) {
				UserService.searchUserIsFollowed({
					userId: $scope.user.id,
					toId: $stateParams.userId
				}, function(data) {
					$scope.isFollower = (true == data || "true" == data) ? true : false;
					// console.log($scope.isFollower);
				});
			}
		});
	};

	this.follow = function() {
		if ($scope.user == null) {
			esNativeCore.originalLogin();
			return;
		}

		UserService.follow({
			toId: $stateParams.userId
		}, function(data) {
			if (data && data.toId == $stateParams.userId) {
				$scope.isFollower = true;
				cordovaUtil.sendNativeMessage("refresh_friend_list", {});
			}
		});
	}

	this.unfollow = function() {
		UserService.unfollow({
			toId: $stateParams.userId
		}, function(data) {
			if (data) {
				$scope.isFollower = false;
				cordovaUtil.sendNativeMessage("refresh_friend_list", {});
			}
		});
	}

	$scope.changeFollowUser = function() {
		if (true == $scope.isFollower) {
			self.unfollow();
		} else {
			self.follow();
		}
	}

	$scope.gotoNativeDetailCoursePage = function(courseId) {
		cordovaUtil.openNativeCourseDetailPage(courseId, "course");
	};
}

app.controller('TeacherTodoListController', ['$scope', '$stateParams', 'AnalysisService', TeacherTodoListController]);

function TeacherTodoListController($scope, $stateParams, AnalysisService) {

	Chart.defaults.global.tooltipTemplate = "<%= value %>";
	Chart.defaults.global.tooltipEvents = [""];
	Chart.defaults.global.animation = false;
	Chart.defaults.global.tooltipFillColor = "rgba(0,0,0,0)";
	Chart.defaults.global.tooltipFontColor = "#000";
	Chart.defaults.global.scaleLineColor = "rgba(0,0,0,0)";

	var self = this;

	$scope.courseClickEvent = function() {
		alert(213);
	}

	$scope.initChartData = function() {
		$scope.showLoad();
		AnalysisService.getCourseChartData({
			courseId: $stateParams.courseId
		}, function(data) {
			$scope.hideLoad();
			if (data.error) {
				$scope.toast(data.error.message);
				return;
			}
			$scope.charts = data;
		});
	}

	$scope.loadCharts = function() {
		setTimeout(function() {
			for (var i = 0; i < $scope.charts.length; i++) {
				initChart($scope.charts[i], i);
			};
		}, 10);
	};

	function initChart(chartData, id) {
		var ctx = document.getElementById("chart_" + id).getContext("2d");
		var chartLineColor = chartData.chartLineColor || "#03c777";
		var data = {
			labels: chartData.labelData,
			datasets: [{
				label: "My First dataset",
				fillColor: "rgba(0, 0, 0, 0)",
				strokeColor: chartLineColor,
				pointColor: chartLineColor,
				pointStrokeColor: "#fff",
				pointHighlightFill: chartLineColor,
				pointHighlightStroke: chartLineColor,
				data: chartData.pointData
			}]
		};

		var defaults = {
			scaleShowGridLines: true,
			bezierCurve: false,
			pointDot: true,
			pointDotRadius: 2
		};

		function showToolTips(lineChart) {
			var activePoints = lineChart.datasets[0].points;
			lineChart.eachPoints(function(point) {
				point.restore(['fillColor', 'strokeColor']);
			});
			Chart.helpers.each(activePoints, function(activePoint) {
				activePoint.fillColor = activePoint.highlightFill;
				activePoint.strokeColor = activePoint.highlightStroke;
			});
			lineChart.showTooltip(activePoints);
		}
		var myLineChart, chart = new Chart(ctx);
		var render = Chart.types.Line.prototype.render;

		Chart.types.Line.prototype.render = function(reflow) {
			var self = this;
			render.call(this, reflow);
			setTimeout(function() {
				showToolTips(self);
			}, 10);
		};

		myLineChart = chart.Line(data, defaults);
	}
}

app.controller('HomeworkTeachingController', ['$scope', '$stateParams', 'HomeworkManagerService', HomeworkTeachingController]);

function HomeworkTeachingController($scope, $stateParams, HomeworkManagerService) {

	var self = this;

	this.filter = function(data) {
		var users = data.users;
		var homeworkResults = data.homeworkResults;
		for (var i = 0; i < homeworkResults.length; i++) {
			homeworkResults[i]["user"] = users[homeworkResults[i]["userId"]];
		};
		data.homeworkResults = homeworkResults;
		console.log(data);
		return data;
	};

	$scope.showHomeWorkResult = function(homeworkResult) {
		alert("暂不支持在客户端批改作业");
	};

	$scope.initTeachingResult = function() {
		HomeworkManagerService.teachingResult({
			start: 3,
			courseId: $stateParams.courseId
		}, function(data) {
			$scope.teachingResult = self.filter(data);
		});
	};
}

app.controller('ThreadTeachingController', ['$scope', '$stateParams', 'ThreadManagerService', 'cordovaUtil', ThreadTeachingController]);

function ThreadTeachingController($scope, $stateParams, ThreadManagerService, cordovaUtil) {

	var self = this;

	$scope.courseId = $stateParams.courseId;

	this.filter = function(data) {
		var users = data.users;
		var threads = data.threads;

		for (var i = 0; i < threads.length; i++) {
			threads[i]["user"] = users[threads[i]["userId"]];
		};

		data.threads = threads;
		return data;
	};

	$scope.showThreadChatView = function(thread) {
		cordovaUtil.startAppView("threadDiscuss", {
			type: "thread.post",
			targetType: 'course',
			targetId: thread.courseId,
			lessonId: thread.lessonId,
			threadId: thread.id,
			threadType: "question"
		});
	};

	$scope.initQuestionResult = function(limit) {
		$scope.showLoad();
		ThreadManagerService.questionResult({
			start: limit,
			courseId: $stateParams.courseId
		}, function(data) {
			$scope.hideLoad();
			$scope.teachingResult = self.filter(data);
		});
	};
}